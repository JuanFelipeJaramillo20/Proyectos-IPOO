package ejemplomenu;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.ImageIcon;


public class CrearPDF {

    public void prueba() {
        // step 1: creation of a document-object        
        Document document = new Document();

        try {
            // step 2: creation of the writer
            PdfWriter writer = PdfWriter.getInstance(
                    document, new FileOutputStream("Ejemplo.pdf"));

            // step 3: we open the document
            document.open();

            // step 4: we grab the ContentByte and do some stuff with it
            PdfContentByte cb = writer.getDirectContent();
            Graphics g = cb.createGraphicsShapes(
                    PageSize.A4.getWidth(), PageSize.A4.getHeight());
            
            Font font = new Font("Arial", Font.BOLD + Font.ITALIC, 18);
            g.setFont(font);

            g.setColor(Color.red);
            g.drawString("Titulo de la pagina", 150, 80);

            g.setColor(Color.green);
            g.drawLine(1, 1, 200, 200);

            g.setColor(Color.blue);
            g.drawRect(200, 200, 300, 300);

            g.setColor(new Color(154, 171, 237));
            g.fillOval(350, 100, 100, 100);
                        
            ImageIcon img = new ImageIcon(getClass().getResource("imagenes/java-duke-guitar.png"));
            g.drawImage(img.getImage(), 230, 220, 250, 250, null);

        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }

        // step 5: we close the document
        document.close();
    }

    public static void main(String[] args) {
        CrearPDF obj = new CrearPDF();
        obj.prueba();
    }

}

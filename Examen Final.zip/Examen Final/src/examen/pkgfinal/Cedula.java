/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

class Cedula {
    
    private int numero;
    private int diaExpedicion;
    private int mesExpedicion;
    private int anioExpedicion;

    public Cedula(int numero, int diaExpedicion, int mesExpedicion, int anioExpedicion) {
        this.numero = numero;
        this.diaExpedicion = diaExpedicion;
        this.mesExpedicion = mesExpedicion;
        this.anioExpedicion = anioExpedicion;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getDiaExpedicion() {
        return diaExpedicion;
    }

    public void setDiaExpedicion(int diaExpedicion) {
        this.diaExpedicion = diaExpedicion;
    }

    public int getMesExpedicion() {
        return mesExpedicion;
    }

    public void setMesExpedicion(int mesExpedicion) {
        this.mesExpedicion = mesExpedicion;
    }

    public int getAnioExpedicion() {
        return anioExpedicion;
    }

    public void setAnioExpedicion(int anioExpedicion) {
        this.anioExpedicion = anioExpedicion;
    }

    @Override
    public String toString() {
        return '{' + " numero=" + numero + "Fecha de Expedicion=" + diaExpedicion + "/"+ mesExpedicion + "/" + anioExpedicion +'}';
    }
    
    
    
}

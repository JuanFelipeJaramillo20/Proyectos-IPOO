/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ExamenFinal {

    private ArrayList<Trabajador> listaEmpleados;
    
    public void inicializar(){
        listaEmpleados = new ArrayList();
    }
    
    public boolean buscarCedula(int cedula){
        boolean encontrado = false;
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(cedula == listaEmpleados.get(i).getCedula().getNumero()){
                encontrado = true;
            }
        }
        return encontrado;
    }
    
    public Trabajador buscarPorCedula(int cedula){
        Trabajador temp = null;
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(cedula == listaEmpleados.get(i).getCedula().getNumero()){
                temp = listaEmpleados.get(i);
            }
        }
        return temp;
    }
    
    public ArrayList<Trabajador> buscarPorTipo(String tipo){
        ArrayList<Trabajador> lista = new ArrayList();
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(listaEmpleados.get(i).getTipoTrabajador().equals(tipo)){
                lista.add(listaEmpleados.get(i));
            }
        }
        return  lista;
    }
    
    public void modificarDatosTrabajador(String datoAModificar, Trabajador trabajador){
        if(datoAModificar.equals("Nombres")){
            trabajador.setNombres(JOptionPane.showInputDialog("Ingrese el nuevo nombre"));
        }else if(datoAModificar.equals("Apellidos")){
            trabajador.setApellidos(JOptionPane.showInputDialog("Ingrese los nuevos apellidos"));
        }else if(datoAModificar.equals("Género")){
            trabajador.setGenero(Utilerias.leerGenero());
        }else if(datoAModificar.equals("Dia de nacimiento")){
            trabajador.getInformacionNacimiento().setDiaNacimiento(Utilerias.leerInt("Ingrese el nuevo día de nacimiento"));
        }else if(datoAModificar.equals("Mes de nacimiento")){
            trabajador.getInformacionNacimiento().setMesNacimiento(Utilerias.leerInt("Ingrese el nuevo mes de nacimiento"));
        }else if(datoAModificar.equals("Año de nacimiento")){
            trabajador.getInformacionNacimiento().setAnioNacimiento(Utilerias.leerInt("Ingrese el nuevo año de nacimiento"));
        }else if(datoAModificar.equals("Lugar de nacimiento")){
            trabajador.getInformacionNacimiento().setLugarNacimiento(JOptionPane.showInputDialog("Ingrese el nuevo lugar de nacimiento"));
        }else if(datoAModificar.equals("Dia de expedición de cédula")){
            trabajador.getCedula().setDiaExpedicion(Utilerias.leerInt("Ingrese el nuevo dia de expedición de la cédula"));
        }else if(datoAModificar.equals("Mes de expedición de cédula")){
            trabajador.getCedula().setMesExpedicion(Utilerias.leerInt("Ingrese el nuevo mes de expedición de la cédula"));
        }else if(datoAModificar.equals("Año de expedición de cédula")){
            trabajador.getCedula().setAnioExpedicion(Utilerias.leerInt("Ingrese el nuevo año de expedición de la cédula"));
        }else if(datoAModificar.equals("Horas extras trabajadas (Solo válido para vigilantes)")){
            TrabajadorVigilante temp = (TrabajadorVigilante) trabajador;
            temp.setHorasExtrasTrabajadas(Utilerias.leerDouble("Ingrese la nueva cantidad de horas extras trabajadas"));
        }else if(datoAModificar.equals("Horas de investigación (solo válido para profesores de tiempo completo)")){
            TrabajadorDocenteTiempoCompleto temp = (TrabajadorDocenteTiempoCompleto) trabajador;
            temp.setHorasInvestigacion(Utilerias.leerDouble("Ingrese la nueva cantidad de horas extras trabajadas"));
        }else if(datoAModificar.equals("estudios")){
            if (trabajador.getTipoTrabajador().equals("Administrativo")) {
                TrabajadorAdministrativo temp = (TrabajadorAdministrativo) trabajador;
                temp.setEstudios();
            }else if (trabajador.getTipoTrabajador().equals("Docente tiempo completo")) {
                TrabajadorDocenteTiempoCompleto temp = (TrabajadorDocenteTiempoCompleto) trabajador;
                temp.setEstudios();
            }
        }else if(datoAModificar.equals("¿Participa en grupos de investigación? (Solo para docentes tiempo completo)")){
            
        }
    }

    public void modificarHorasExtrasVigilante(TrabajadorVigilante vigilante, double valor){
        vigilante.setValorHorasExtras(valor);
    }
    
    public void modificarValorHorasExtras(double valor){
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(listaEmpleados.get(i).getTipoTrabajador().equals("Vigilante")){
                modificarHorasExtrasVigilante( (TrabajadorVigilante) listaEmpleados.get(i), valor);
            }
        }
    }
    
    public void eliminarTrabajador(int cedula){
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(cedula == listaEmpleados.get(i).getCedula().getNumero()){
                listaEmpleados.remove(i);
                break;
            }
        }
    }
    
    private void eliminarTrabajadoresPorTipo(String tipoAEliminar) {
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(listaEmpleados.get(i).getTipoTrabajador().equals(tipoAEliminar)){
                listaEmpleados.remove(i);
            }
        }
    }
    
    private void consultarTrabajadorPorCedula(int cedulaConsulta) {
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(listaEmpleados.get(i).getCedula().getNumero() == cedulaConsulta){
                JOptionPane.showMessageDialog(null, listaEmpleados.get(i).toString());
                break;
            }
        }
    }
    
    private void consultarPorTituloUniversitario(String titulo) {
        ArrayList<Trabajador> lista = new ArrayList();
        for (int i = 0; i < listaEmpleados.size(); i++) {
            if(listaEmpleados.get(i).getTipoTrabajador().equals("Administrativo")){
                TrabajadorAdministrativo temp = (TrabajadorAdministrativo) listaEmpleados.get(i);
                if(temp.getEstudios().equals(titulo)){
                    lista.add(temp);
                }
            }
            if(listaEmpleados.get(i).getTipoTrabajador().equals("Docente tiempo completo")){
                TrabajadorDocenteTiempoCompleto temp = (TrabajadorDocenteTiempoCompleto) listaEmpleados.get(i);
                if(temp.getEstudios().equals(titulo)){
                    lista.add(temp);
                }
            }
        }
        JOptionPane.showMessageDialog(null, concatenarArrayList(lista));
    }
    
    public String concatenarArrayList(ArrayList<Trabajador> lista){
        String listaString = "";
        for (int i = 0; i < lista.size(); i++) {
            if(lista.get(i).getTipoTrabajador().equals("Vigilante")){
                TrabajadorVigilante temp = (TrabajadorVigilante) lista.get(i);
                listaString += temp.toString() + "\n";
            }else if(lista.get(i).getTipoTrabajador().equals("Administrativo")){
                TrabajadorAdministrativo temp = (TrabajadorAdministrativo) lista.get(i);
                listaString += temp.toString() + "\n";
            }else if(lista.get(i).getTipoTrabajador().equals("Docente tiempo completo")){
                TrabajadorDocenteTiempoCompleto temp = (TrabajadorDocenteTiempoCompleto) lista.get(i);
                listaString += temp.toString() + "\n";
            } 
        }
        return listaString;
    }
    
    public void menu(){
        inicializar();
        int opcion;
        do {            
            String menu = JOptionPane.showInputDialog("Bienvenido al sistema de gestión de empleados de la universidad. Por favor seleccione una opción: \n"
                    + "1. Ingresar datos de trabajador. \n"
                    + "2. Calcular el total a pagar de un trabajador. \n"
                    + "3. Listar trabajadores. \n"
                    + "4. Listar trabajadores por tipo. \n"
                    + "5. Modificar trabajador \n"
                    + "6. Modificar el valor de la hora extra. \n"
                    + "7. Eliminar trabajador. \n"
                    + "8. Eliminar trabajadores. \n"
                    + "9. Consultar por cédula. \n"
                    + "10. Consultar por título universitario. \n"
                    + "11. Salir de la aplicación.");
            menu = menu.trim();
            opcion = Integer.parseInt(menu);
            switch(opcion){
                case 1:
                    String tipoTrabajador = Utilerias.leerTipoTrabajador();
                    int cedula = 0;
                    do {                        
                        cedula = Utilerias.leerInt("Ingrese el número de cédula del trabajador (Si la pantalla no continua es porque el número de cédula ya está registrado en el sistema)");
                    } while (buscarCedula(cedula));
                    String fechaExpedicion = JOptionPane.showInputDialog("Ingrese la fecha de expedición de la cédula (en formato 24/11/2015)");
                    String[] partes = fechaExpedicion.split("/");
                    int diaExpedicion = Integer.parseInt(partes[0]);
                    int mesExpedicion = Integer.parseInt(partes[1]);
                    int anioExpedicion = Integer.parseInt(partes[2]);
                    Cedula cedulaTrabajador = new Cedula(cedula, diaExpedicion, mesExpedicion, anioExpedicion);
                    String nombres = JOptionPane.showInputDialog("Ingrese los nombres del trabajador");
                    String apellidos = JOptionPane.showInputDialog("Ingrese los apellidos del trabajador");
                    String genero = Utilerias.leerGenero();
                    String fechaNacimiento = JOptionPane.showInputDialog("Ingrese la fecha de nacimiento del trabajador (en formato 24/11/1999)");
                    String[] partes2 = fechaNacimiento.split("/");
                    int diaNacimiento = Integer.parseInt(partes2[0]);
                    int mesNacimiento = Integer.parseInt(partes2[1]);
                    int anioNacimiento = Integer.parseInt(partes[2]);
                    String lugarNacimiento = JOptionPane.showInputDialog("Ingrese el lugar de nacimiento del trabajador");
                    informacionNacimiento informNacimientoTrabajador = new informacionNacimiento(diaNacimiento, mesNacimiento, anioNacimiento, lugarNacimiento);
                    
                    if(tipoTrabajador.equals("Vigilante")){
                        double horasExtras = Utilerias.leerDouble("Ingrese el número de horas extras trabajadas por el vigilante");
                        TrabajadorVigilante vigilante = new TrabajadorVigilante(horasExtras, cedulaTrabajador, nombres, apellidos, genero, informNacimientoTrabajador, tipoTrabajador);
                        listaEmpleados.add(vigilante);
                    }else if(tipoTrabajador.equals("Administrativo")){
                        String estudios = Utilerias.leerEstudiosAdministrativo();
                        TrabajadorAdministrativo administrativo = new TrabajadorAdministrativo(estudios, cedulaTrabajador, nombres, apellidos, genero, informNacimientoTrabajador, tipoTrabajador);
                        listaEmpleados.add(administrativo);
                    }else if(tipoTrabajador.equals("Docente tiempo completo")){
                        String estudios = Utilerias.leerEstudiosDocentes();
                        boolean investiga = Utilerias.leerBoolean();
                        double horasInvestigacion = 0.0;
                        if(investiga){
                           horasInvestigacion = Utilerias.leerDouble("¿Cuantas horas de investigación registra el docente?");
                        }
                        TrabajadorDocenteTiempoCompleto docente = new TrabajadorDocenteTiempoCompleto(estudios, investiga, horasInvestigacion, cedulaTrabajador, nombres, apellidos, genero, informNacimientoTrabajador, tipoTrabajador);
                        listaEmpleados.add(docente);
                    }
                    break;
                case 2:
                    int cedulaABuscar = Utilerias.leerInt("Ingrese la cédula del trabajador del cual quiere calcular el salario");
                    Trabajador temp = buscarPorCedula(cedulaABuscar);
                    if(temp != null){
                        temp.calcularSalario();
                        JOptionPane.showMessageDialog(null, "El salario neto del trabajador es: " + temp.getSalario() + " COP" + "\n"
                                + "Los descuentos de salud del trabajador son: " + (temp.getSalario() * 0.04) + "\n"
                                        + "Los descuentos de pensión del trabajador son: " + (temp.getSalario() * 0.04) + "\n"
                                                + "El salario que recibe el trabajador es: " + (temp.getSalario() - (temp.getSalario() * 0.04) - (temp.getSalario() * 0.04)));
                    }
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, concatenarArrayList(listaEmpleados));
                    break;
                case 4:
                    String tipo = Utilerias.leerTipoTrabajador();
                    JOptionPane.showMessageDialog(null, concatenarArrayList(buscarPorTipo(tipo)));
                    break;
                case 5:
                    int cedulaAModificar = Utilerias.leerInt("Ingrese la cédula del trabajador el cual quiere modificar");
                    if(buscarPorCedula(cedulaAModificar) != null){
                        modificarDatosTrabajador(Utilerias.leerModificacion(), buscarPorCedula(cedulaAModificar));
                        JOptionPane.showMessageDialog(null, "Datos modificados correctamente! Nuevos datos:" + buscarPorCedula(cedulaAModificar).toString());
                    }
                    break;
                case 6:
                    double nuevoValorHorasExtras = Utilerias.leerDouble("Ingrese el nuevo valor de las horas extras");
                    modificarValorHorasExtras(nuevoValorHorasExtras);
                    break;
                case 7:
                    int cedulaAEliminar = Utilerias.leerInt("Ingrese el número de cédula del trabajador que quiere eliminar");
                    eliminarTrabajador(cedulaAEliminar);
                    break;
                case 8:
                    String tipoAEliminar = Utilerias.leerTipoTrabajador();
                    eliminarTrabajadoresPorTipo(tipoAEliminar);
                    break;
                case 9:
                    int cedulaConsulta = Utilerias.leerInt("Ingrese la cédula del trabajador el cual quiere eliminar");
                    consultarTrabajadorPorCedula(cedulaConsulta);
                    break;
                case 10:
                    String titulo = Utilerias.leerEstudiosGenerales();
                    consultarPorTituloUniversitario(titulo);
                    break;
                case 11:
                    JOptionPane.showMessageDialog(null, "Gracias por utilizar la aplicación. Que tenga un buen día.");
                    break;
                default: JOptionPane.showMessageDialog(null, "Opción incorrecta. Por favor intente de nuevo.");
            }
        } while (opcion != 11);
        
    }
    public static void main(String[] args) {
        ExamenFinal examen = new ExamenFinal();
        examen.menu();
    }
    
}

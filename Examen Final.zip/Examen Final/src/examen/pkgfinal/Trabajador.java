/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import java.util.Date;



public class Trabajador {
    
    
    private Cedula cedula;
    private String nombres;
    private String apellidos;
    private String genero;
    private informacionNacimiento informacionNacimiento;
    private String tipoTrabajador;
    private double salario;
    
    public static final char VIGILANTE = 'V';
    public static final char ADMINISTRATIVO = 'A';
    public static final char DOCENTE_TIEMPO_COMPLETO = 'T';
    public static final double SALARIO_BASICO_POR_HORA = 3785;
    public static final double SALARIO_MINIMO_MENSUAL = 908526;
    public static final double SALARIO_MINIMO_DIARIO = 30284;

    public Trabajador(Cedula cedula, String nombres, String apellidos, String genero, informacionNacimiento informacionNacimiento, String tipoTrabajador) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.genero = genero;
        this.informacionNacimiento = informacionNacimiento;
        this.tipoTrabajador = tipoTrabajador;
        salario = 0.0;
    }
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Cedula getCedula() {
        return cedula;
    }

    public void setCedula(Cedula cedula) {
        this.cedula = cedula;
    }

    public informacionNacimiento getInformacionNacimiento() {
        return informacionNacimiento;
    }

    public void setInformacionNacimiento(informacionNacimiento informacionNacimiento) {
        this.informacionNacimiento = informacionNacimiento;
    }
   
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTipoTrabajador() {
        return tipoTrabajador;
    }

    public void setTipoTrabajador(String tipoTrabajador) {
        this.tipoTrabajador = tipoTrabajador;
    }
    
    public void calcularSalario(){
        salario = SALARIO_MINIMO_MENSUAL;
    }
    
    @Override
    public String toString() {
        return  "cedula=" + cedula.toString() + ", nombres=" + nombres + ", apellidos=" + apellidos + ", genero=" + genero + ", informacionNacimiento=" + informacionNacimiento.toString() + ", salario=" + salario + '}';
    }
}

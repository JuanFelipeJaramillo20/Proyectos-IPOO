/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import java.util.Date;


public class TrabajadorAdministrativo extends Trabajador{
    
    public String estudios;

    public TrabajadorAdministrativo(String estudios, Cedula cedula, String nombres, String apellidos, String genero, informacionNacimiento informacionNacimiento, String tipoTrabajador) {
        super(cedula, nombres, apellidos, genero, informacionNacimiento, tipoTrabajador);
        this.estudios = estudios;
    }

    @Override
    public void calcularSalario() {
            if(estudios.equals("Técnico")){
                setSalario(SALARIO_MINIMO_MENSUAL * 1.3);
            }else if(estudios.equals("Tecnólogo")){
                setSalario(SALARIO_MINIMO_MENSUAL * 1.5);
            }else if(estudios.equals("Profesional")){
                setSalario(SALARIO_MINIMO_MENSUAL * 2);
            }else if(estudios.equals("Especialista o superior")){
                setSalario(SALARIO_MINIMO_MENSUAL * 3);
            }
    }

    public String getEstudios() {
        return estudios;
    }

    public void setEstudios() {
        this.estudios = Utilerias.leerEstudiosAdministrativo();
    }

    @Override
    public String toString() {
        return " Administrativo{" + " " + super.toString() +  ", estudios=" + estudios + '}';
    }
    
    
    
}

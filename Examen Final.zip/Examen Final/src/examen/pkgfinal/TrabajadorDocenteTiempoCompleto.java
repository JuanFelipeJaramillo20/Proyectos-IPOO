/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import java.util.Date;


public class TrabajadorDocenteTiempoCompleto extends Trabajador{
    
    private String estudios;
    private boolean participaGruposDeInvestigacion;
    private double horasInvestigacion;

    public TrabajadorDocenteTiempoCompleto(String estudios, boolean participaGruposDeInvestigacion, double horasInvestigacion, Cedula cedula, String nombres, String apellidos, String genero, informacionNacimiento informacionNacimiento, String tipoTrabajador) {
        super(cedula, nombres, apellidos, genero, informacionNacimiento, tipoTrabajador);
        this.estudios = estudios;
        this.participaGruposDeInvestigacion = participaGruposDeInvestigacion;
        this.horasInvestigacion = horasInvestigacion;
    }

    public void setHorasInvestigacion(double horasInvestigacion) {
        this.horasInvestigacion = horasInvestigacion;
    }

    public void setParticipaGruposDeInvestigacion(boolean participaGruposDeInvestigacion) {
        this.participaGruposDeInvestigacion = participaGruposDeInvestigacion;
    }

    public void setEstudios() {
        this.estudios = Utilerias.leerEstudiosDocentes();
    }
    

    @Override
    public void calcularSalario() {
        if(estudios.equals("Profesional")){
            setSalario(SALARIO_MINIMO_MENSUAL * 2.5);
        }else if(estudios.equals("Especialista")){
            setSalario(SALARIO_MINIMO_MENSUAL * 3);
        }else if(estudios.equals("Magister")){
            setSalario(SALARIO_MINIMO_MENSUAL * 4);
        }
        
        if(participaGruposDeInvestigacion){
            setSalario(getSalario() + (horasInvestigacion * SALARIO_MINIMO_DIARIO));
        }
    }

    public String getEstudios() {
        return estudios;
    }

    @Override
    public String toString() {
        return " Docente Tiempo Completo{" + " " + super.toString() + ", estudios=" + estudios + ", participaGruposDeInvestigacion=" + participaGruposDeInvestigacion + ", horasInvestigacion=" + horasInvestigacion + '}';
    }
    
    
}

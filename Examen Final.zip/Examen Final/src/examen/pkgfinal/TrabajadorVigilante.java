/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import java.util.Date;


public class TrabajadorVigilante extends Trabajador{
    
    private double horasExtrasTrabajadas;
    private double valorHorasExtras;

    public TrabajadorVigilante(double horasExtrasTrabajadas, Cedula cedula, String nombres, String apellidos, String genero, informacionNacimiento informacionNacimiento, String tipoTrabajador) {
        super(cedula, nombres, apellidos, genero, informacionNacimiento, tipoTrabajador);
        this.horasExtrasTrabajadas = horasExtrasTrabajadas;
        valorHorasExtras = SALARIO_BASICO_POR_HORA * 1.5;
    }

    public double getHorasExtrasTrabajadas() {
        return horasExtrasTrabajadas;
    }

    public void setHorasExtrasTrabajadas(double horasExtrasTrabajadas) {
        this.horasExtrasTrabajadas = horasExtrasTrabajadas;
    }

    public double getValorHorasExtras() {
        return valorHorasExtras;
    }

    public void setValorHorasExtras(double valorHorasExtras) {
        this.valorHorasExtras = valorHorasExtras;
    }
    

    @Override
    public void calcularSalario() {
        setSalario( SALARIO_MINIMO_MENSUAL + (valorHorasExtras * horasExtrasTrabajadas));
    }

    @Override
    public String toString() {
        return " Vigilante{" +  " " + super.toString() + ", horasExtrasTrabajadas=" + horasExtrasTrabajadas + ", valorHorasExtras=" + valorHorasExtras + '}';
    }

    
    
    
    
}

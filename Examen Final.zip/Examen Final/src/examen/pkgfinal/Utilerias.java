/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package examen.pkgfinal;

import javax.swing.JOptionPane;


public class Utilerias {
    
    public static String[] tiposTrabajadores ={"Vigilante", "Administrativo", "Docente tiempo completo"};
    public static String[] generos = {"Masculino", "Femenino", "Otro"};
    public static String[] estudiosAdministrativo = {"Técnico", "Tecnólogo", "Profesional", "Especialista o superior"};
    public static String[] estudiosDocentes = {"Profesional", "Especialista", "Magister"};
    public static String[] modificarAtributos = { "Nombres", "Apellidos", "Género", "Dia de nacimiento", "Mes de nacimiento", "Año de nacimiento", "Lugar de nacimiento", "Dia de expedición de cédula", "Mes de expedición de cédula", "Año de expedición de cédula", "Horas extras trabajadas (Solo válido para vigilantes)","Horas de investigación (solo válido para profesores de tiempo completo)", "estudios", "¿Participa en grupos de investigación? (Solo para docentes tiempo completo)" };
    public static String[] booleanos = { "Si" , "No" };
    public static String[] estudiosGenerales = {"Técnico", "Tecnólogo", "Profesional", "Especialista o superior", "Magister"};
    
    public static double leerDouble(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        double real = Double.parseDouble(ent);
        return real;
    }
    
    public static int leerInt(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        int entero = Integer.parseInt(ent);
        return entero;
    }
    
    public static String leerTipoTrabajador(){
        String tipo = (String) JOptionPane.showInputDialog(null, "Seleccione el tipo de trabajador", "Tipo trabajador",JOptionPane.QUESTION_MESSAGE, null, tiposTrabajadores, tiposTrabajadores[0]);
        return tipo;
    }
    
    public static String leerGenero(){
        String genero = (String) JOptionPane.showInputDialog(null,"Seleccione el género del trabajador", "Género", JOptionPane.QUESTION_MESSAGE, null, generos, generos[0]);
        return genero;
    }
    
    public static String leerEstudiosAdministrativo(){
        String estudios = (String) JOptionPane.showInputDialog(null,"Seleccione el nivel de estudios del trabajador administrativo","Nivel de estudios",JOptionPane.QUESTION_MESSAGE,null,estudiosAdministrativo,estudiosAdministrativo[0]);
        return estudios;
    }
    
    public static String leerEstudiosDocentes(){
        String estudios = (String) JOptionPane.showInputDialog(null,"Seleccione el nivel de estudios del docente de tiempo completo", "Nivel de estudios", JOptionPane.QUESTION_MESSAGE, null, estudiosDocentes, estudiosDocentes[0]);
        return estudios;
    }
    
    public static String leerModificacion(){
        String modificar = (String) JOptionPane.showInputDialog(null,"Seleccione el dato a modificar","Modificación de datos de trabajador", JOptionPane.QUESTION_MESSAGE, null, modificarAtributos, modificarAtributos[0]);
        return modificar;
    }
    
    public static String leerEstudiosGenerales(){
        String estudios = (String) JOptionPane.showInputDialog(null, "Seleccione el nivel de estudios de los docentes que quiere consultar", "Nivel de estudios", JOptionPane.QUESTION_MESSAGE, null, estudiosGenerales, estudiosGenerales[0]);
        return estudios;
    }

    static boolean leerBoolean() {
        boolean booleano = false;
        String opcion = (String) JOptionPane.showInputDialog(null,"¿El profesor es parte activa de grupos de investigación?","Grupos de investigación", JOptionPane.QUESTION_MESSAGE, null, booleanos, booleanos[0]);
        if(opcion.equals("Si")){
         booleano = true;
        }
        return booleano;
    }
}

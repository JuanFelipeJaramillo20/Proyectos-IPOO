/*
Juan Felipe Jaramillo Losada - 202060257
*/
package examenopcional1;

import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class ExamenOpcional1 {
    
    Punto1 punto1 = new Punto1();
    Punto2 punto2 = new Punto2();
    
    public void Menu(){
        int menu = 0;
        String op = JOptionPane.showInputDialog("Bienvenido al examen opcional 1. Por favor seleccione una opción: \n"
                + "1. Método de Kuder Richardson. \n"
                + "2. Llenar arreglo con las condiciones dadas en el enunciado. \n"
                + "0. Salir");
        menu = Integer.parseInt(op);
        switch(menu){
            case 1: punto1.Menu(); break;
            case 2: punto2.Menu(); break;
            case 0: break;
            default: JOptionPane.showMessageDialog(null, "Opción incorrecta. Por favor intente de nuevo", "Opción Incorrecta", JOptionPane.ERROR_MESSAGE);
        }while(menu != 0);
    }

  
    public static void main(String[] args) {
        ExamenOpcional1 principal = new ExamenOpcional1();
        principal.Menu();
    }
    
}

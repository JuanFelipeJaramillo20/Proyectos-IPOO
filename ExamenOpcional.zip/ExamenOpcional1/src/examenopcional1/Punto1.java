/*
Juan Felipe Jaramillo Losada - 202060257
*/
package examenopcional1;

import java.util.Arrays;
import java.util.Random;
import javax.swing.JOptionPane;



/**
 *
 * @author juanf
 */
public class Punto1 {
    
    public int[][] llenarMatriz(int N, int M){
        int[][] matrizRespuestas = new int[N][M];
        
        for (int i = 0; i < matrizRespuestas.length; i++) {
            for (int j = 0; j < matrizRespuestas[i].length; j++) {
                double numero = Math.random();
                if (numero <= 0.5){
                    matrizRespuestas[i][j] = 0;
                }else{
                    matrizRespuestas[i][j] = 1;
                }
            }
            
        }
        return matrizRespuestas;
    }
    
    public double[] calcularProbabilidadPositiva( int[][] matrizRespuestas){
        double[] probabilidadPositiva = new double[matrizRespuestas[0].length];
        double acumulador = 0;
        double contador = 0;
        
        for (int i = 0; i < matrizRespuestas[0].length; i++) {
            for (int j = 0; j < matrizRespuestas.length; j++) {
                acumulador += matrizRespuestas[j][i];
                contador++;
            }
            
            probabilidadPositiva[i] = acumulador/contador;
            acumulador = 0;
            contador= 0;
        }
        return probabilidadPositiva;
    }
    
    public double[] calcularProbabilidadNegativa (double[] probabilidadPositiva){
        double[] probabilidadNegativa = new double[probabilidadPositiva.length];
        for (int i = 0; i < probabilidadNegativa.length; i++) {
            probabilidadNegativa[i] = 1 - probabilidadPositiva[i];
        }
        return probabilidadNegativa;
    }
    
    public double[] multiplicarProbabilidadNegativaYPositiva(double[] probabilidadPositiva, double[] probabilidadNegativa){
        double[] probabilidadMultiplicada = new double[probabilidadPositiva.length];
        for (int i = 0; i < probabilidadMultiplicada.length; i++) {
            probabilidadMultiplicada[i] = probabilidadNegativa[i] * probabilidadPositiva[i];
        }
        return probabilidadMultiplicada;
    }
    
    public double[] calcularSumatoriaPorRespuesta(int[][] matrizRespuestas){
        double[] sumatoriaRespuestas = new double[matrizRespuestas.length];
        double sumatoria = 0.0;
        for (int i = 0; i < matrizRespuestas.length; i++) {
            for (int j = 0; j < matrizRespuestas[0].length; j++) {
                sumatoria += matrizRespuestas[i][j];
            }
            sumatoriaRespuestas[i] = sumatoria;
            sumatoria = 0;
        }
        return sumatoriaRespuestas;
    }
    
    public double calcularPromedio(double[] arreglo){
        int contador = 0;
        double acumulador = 0.0;
        for (int i = 0; i < arreglo.length; i++) {
            contador++;
            acumulador += arreglo[i];
        }
        return acumulador/contador;
    }
    
    public double calcularVarianza(double[] sumatoriaRespuestas){
        double varianza = 0.0;
        double promedioArreglo = calcularPromedio(sumatoriaRespuestas);
        int contador = 0;
        for (int i = 0; i < sumatoriaRespuestas.length; i++) {
            varianza+= Math.pow(sumatoriaRespuestas[i] - promedioArreglo, 2);
            contador++;
        }
        varianza = varianza/contador;
        return varianza;
    }
    
    public double calcularSumatoriaDeMultiplicacion(int[][] matrizRespuestas){
        double sumatoria = 0.0;
        for (int i = 0; i < multiplicarProbabilidadNegativaYPositiva(calcularProbabilidadPositiva(matrizRespuestas), calcularProbabilidadNegativa(calcularProbabilidadPositiva(matrizRespuestas))).length; i++) {
            sumatoria+= multiplicarProbabilidadNegativaYPositiva(calcularProbabilidadPositiva(matrizRespuestas), calcularProbabilidadNegativa(calcularProbabilidadPositiva(matrizRespuestas)))[i];
        }
        return sumatoria;
    }
    public double formulaKuderRichardson(int[][] matrizRespuestas){
        double kr= 0.0;
        int cantidadPreguntas = matrizRespuestas[0].length;
        double varianzaTotal = calcularVarianza(calcularSumatoriaPorRespuesta(matrizRespuestas));
        double sumatoria = calcularSumatoriaDeMultiplicacion(matrizRespuestas);
        kr = ( cantidadPreguntas / (cantidadPreguntas - 1) ) * ( (varianzaTotal - sumatoria) / varianzaTotal );
        return kr;
    }
    
    public String calcularConfiabilidadEncuesta(int[][] matrizRespuestas){
        double coeficiente = formulaKuderRichardson(matrizRespuestas);
        String confiabilidad = "";
        if(coeficiente < 0.6){
            confiabilidad = "De acuerdo a los datos de la encuesta se determina que el instrumento de recolección de datos(encuesta) tiene una confiabilidad 'muy pobre' y no se aconseja su aplicación. ";
        }else if(coeficiente >= 0.6 && coeficiente < 0.7){
            confiabilidad = "De acuerdo a los datos de la encuesta se determina que el instrumento de recolección de datos(encuesta) tiene una confiabilidad 'medianamente confiable'.";
        }else if(coeficiente >= 0.7 && coeficiente < 0.8){
            confiabilidad = "De acuerdo a los datos de la encuesta se determina que el instrumento de recolección de datos(encuesta) es 'confiable'.";
        }else if (coeficiente >= 0.8){
            confiabilidad = "De acuerdo a los datos de la encuesta se determina que el instrumento de recolección de datos(encuesta) es 'altamente confiable'.";
        }else{
            confiabilidad = "Valor inválido.";
        }
        return confiabilidad;
    }
    
    public void Menu(){
        int N = Integer.parseInt(JOptionPane.showInputDialog("Bienvenido al sistema de método de  Kuder  Richardson. Por favor ingrese el tamaño N de la matriz (filas)"));
        int M = Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese el tamaño M de la matriz (columnas)"));
        int[][] matrizRespuestas = llenarMatriz(N, M).clone();
        JOptionPane.showMessageDialog(null, Arrays.deepToString(matrizRespuestas));
        JOptionPane.showMessageDialog(null, "De acuerdo a los datos de la matriz: \n"
                + "La Varianza total de los datos es: " + calcularVarianza(calcularSumatoriaPorRespuesta(matrizRespuestas)) + "\n"
                + "La sumatoria de la multiplicacion de la probabilidad negativa y positiva es: " + calcularSumatoriaDeMultiplicacion(matrizRespuestas) + "\n"
                + "El resultado de la fórmula Kuder Richardson es: " + formulaKuderRichardson(matrizRespuestas) + "\n"
                + "La confiabilidad de la encuesta es: " + calcularConfiabilidadEncuesta(matrizRespuestas));
    }
}

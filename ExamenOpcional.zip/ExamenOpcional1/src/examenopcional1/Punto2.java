/*
Juan Felipe Jaramillo Losada - 202060257
*/
package examenopcional1;

import java.util.Arrays;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class Punto2 {
    
    public int[] llenar(int T, int M){
        int[] A = new int[T];
        Random numeroR = new Random();
        if (T % 2 != 0){
           for (int i = 0; i < A.length; i = i+2) {
            int resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
            int resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);

            if(i == 0){
                while (resultado1 % 2 == 0 || resultado2 % 2 == 0 || resultado2 < resultado1 || resultado1 <= 0 || resultado2 <= 0) {                    
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                }
            }
            if (i >= 1) {
              if (A[i-1] %2 != 0) {
                  while (resultado1 % 2 != 0 || resultado1 % 2 != 0 || resultado1 < resultado2 || resultado1 <= 0 || resultado2 <= 0) {                      
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                  }
                }else{
                  while (resultado1 >= 0 || resultado2 >=0 || resultado1>resultado2) {                      
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                  }
                }   
            }
            
            A[i] = resultado1;
            if(i+1 <= A.length-1){
                A[i+1] = resultado2;
            }
            
        } 
        }else{
          for (int i = 0; i < A.length; i = i+2) {
            int resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
            int resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);

            if(i == 0){
                while (resultado1 % 2 == 0 || resultado2 % 2 == 0 || resultado2<resultado1 || resultado1 < 0 || resultado2 < 0 || resultado1 == resultado2) {                    
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                }
            }
            if (i >= 1) {
              if (A[i-1] % 2 != 0 && A[i-1] > 0) {
                  while (resultado1 % 2 != 0 || resultado2 % 2 != 0 || resultado1 < resultado2 || resultado1 < 0 || resultado2 < 0 || resultado1 == resultado2) {                      
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                  }
                }else if (A[i-1] < 0) {
                    while (resultado1 % 2 == 0 || resultado2 % 2 == 0 || resultado2<resultado1 || resultado1 < 0 || resultado2 < 0 || resultado1 == resultado2) {                    
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                }
                }else{
                  while (resultado1 >= 0 || resultado2 >=0 || resultado1>resultado2 || resultado1 == resultado2) {                      
                    resultado1 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                    resultado2 = numeroR.nextInt(M - (-M) + 1 ) + (-M);
                  }  
                }

            }
            
            A[i] = resultado1;
            A[i+1] = resultado2;
        }  
        }
        
        return A;
    }
    
    public void Menu(){
       int T =Integer.parseInt(JOptionPane.showInputDialog("Bienvenido al sistema de llenado de matriz aleatoria con condiciones. Por favor ingrese el tamaño (T) del arreglo"));
       int M = Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese el valor entero M que funcionará como rango para llenar el arreglo"));
       JOptionPane.showMessageDialog(null,"Arreglo lleno: \n" + Arrays.toString(llenar(T, M)) );
    }
}

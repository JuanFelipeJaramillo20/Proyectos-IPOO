/*
* Juan Felipe Jaramillo Losada
* Código: 202060257
*/
package examenparcial;

import javax.swing.JOptionPane;


/**
 *
 * @author juanf
 */
public class ExamenParcial {

    Punto1 punto1 = new Punto1();
    Punto2 punto2 = new Punto2();
    public void menu(){
        int menu;
        do {
            String entero = JOptionPane.showInputDialog(
                "Bienvenido al examen parcial \n"
                + "Seleccione una opción.\n" +
                "1. Primer Punto (Gestión de datos almacenados en un arreglo).\n" +
                "2. Segundo punto (Frecuencia de datos en una matriz).\n" +      
                "0. Salir.");
            menu= Integer.parseInt(entero);
            switch(menu){
                case 1: punto1.menu(); break;
                case 2: punto2.menu(); break;
                case 0: break;
                default: JOptionPane.showMessageDialog(null, "Opción incorrecta. Por favor intente de nuevo", "Opción Incorrecta", JOptionPane.ERROR_MESSAGE);
            }
        } while (menu != 0);
    }
    
    public static void main(String[] args) {
        ExamenParcial examenParcial = new ExamenParcial();
        examenParcial.menu();
    }
    
}

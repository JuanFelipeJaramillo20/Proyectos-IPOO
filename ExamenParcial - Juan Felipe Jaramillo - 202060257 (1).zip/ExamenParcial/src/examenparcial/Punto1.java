/*
* Juan Felipe Jaramillo Losada
* Código: 202060257
*/
package examenparcial;

import java.util.Arrays;
import java.util.Collections;
import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class Punto1 {

    private int[] A;
    
    public void inicializarArreglo(int a){
        A = new int[a];
    }
    
    public void ingresarDatoEnArreglo(int x){
        if(A == null){
            JOptionPane.showMessageDialog(null, "El arreglo no se ha inicializado. Por favor ingrese el tamaño del arreglo antes de realizar cualquier otra operación.", "Arreglo no inicializado", JOptionPane.ERROR_MESSAGE);
        }else{
           if (x == 0){
            JOptionPane.showMessageDialog(null, "El número tiene que ser diferente de 0. Intente de nuevo.", "Número inválido", JOptionPane.ERROR_MESSAGE);

        }else{
            if (A[A.length - 1] != 0){
            JOptionPane.showMessageDialog(null, "El arreglo está lleno. No se pueden ingresar mas datos.", "Arreglo lleno", JOptionPane.ERROR_MESSAGE);
        }else{
            for (int i = 0; i < A.length; i++) {
                if(A[i] == 0){
                    A[i] = x;
                    break;
                }
                
            }
        }
        }
        ordenarArreglo();  
        }
       

    }
    
    public void ordenarArreglo(){
        int contadorImpares = 0;
        int contadorPares = 0;
        int contadorNegativos = 0;
        for (int i = 0; i < A.length; i++) {
            if( A[i] < 0){
                contadorNegativos++;
            }else if((A[i] % 2) != 0 && A[i] != 0){
                contadorImpares++;
            }else if( (A[i] % 2 == 0) && (A[i] != 0) ){
                contadorPares++;
            }
        }
        int[] auxiliarImpares = new int[contadorImpares];
        int[] auxiliarPares = new int[contadorPares];
        int[] auxiliarNegativos = new int[contadorNegativos];
        
        for (int i = 0; i < A.length; i++) {
            if( A[i] < 0){
                ingresarAuxiliar(auxiliarNegativos, A[i]);
            }else if((A[i] % 2) != 0){
                ingresarAuxiliar(auxiliarImpares, A[i]);
            }else{
                ingresarAuxiliar(auxiliarPares, A[i]);
            }
            
        }
        
        Arrays.sort(auxiliarPares);
        Arrays.sort(auxiliarImpares);
        auxiliarPares = revertirArreglo(auxiliarPares);
        limpiarArreglo(A);
        for (int i = 0; i < auxiliarImpares.length; i++) {
            ingresarDatoAuxiliar(auxiliarImpares[i]);
            
        }
        for (int i = 0; i < auxiliarPares.length; i++) {
            ingresarDatoAuxiliar(auxiliarPares[i]);
            
        }
        for (int i = 0; i < auxiliarNegativos.length; i++) {
            ingresarDatoAuxiliar(auxiliarNegativos[i]);
            
        }

    }
    
    public void ingresarDatoAuxiliar(int x){
        for (int i = 0; i < A.length; i++) {
            if (A[i] == 0){
                A[i] = x;
                break;
            };
            
        }
    }
    
    
    public int[] revertirArreglo(int[] a){
        if( a == null){
            JOptionPane.showMessageDialog(null, "El arreglo no se ha inicializado. Por favor ingrese el tamaño del arreglo antes de realizar cualquier otra operación.", "Arreglo no inicializado", JOptionPane.ERROR_MESSAGE);
        }else{
            for(int i = 0; i < a.length / 2; i++){
            int temporal = a[i];
            a[i] = a[a.length - i - 1];
            a[a.length - i - 1] = temporal;
        }
        }
    
    return a;
    }
    
    public void limpiarArreglo(int[] a){
        for (int i = 0; i < a.length; i++) {
            a[i] = 0;  
        }
    }
    
    public void ingresarAuxiliar(int[] a, int x){
        for (int i = 0; i < a.length; i++) {
            if(a[i] == 0){
                a[i] = x;
                break;
            }    
        }
    }
    
    public String imprimirArreglo(int[] a){
        String arreglo = "";
        if(a == null){
            JOptionPane.showMessageDialog(null, "El arreglo no se ha inicializado. Por favor ingrese el tamaño del arreglo antes de realizar cualquier otra operación.", "Arreglo no inicializado", JOptionPane.ERROR_MESSAGE);
        }else{
        arreglo = "Arreglo A = [ ";
        if (a[0] == 0){
            arreglo += "A está vacío.";
        }else{
           for (int i = 0; i < a.length; i++) {
            if( (i == a.length-1) && a[i] != 0){
               arreglo += a[i]; 
            }else{
               if(a[i] != 0){
             arreglo += a[i] +", ";   
            } 
            }   
        } 
        }
        arreglo += " ]";
    }
    return arreglo;
    }
    
    public String imprimirArregloRevertido(int[] a){
        String arreglo = "";
        if(a == null){
            JOptionPane.showMessageDialog(null, "El arreglo no se ha inicializado. Por favor ingrese el tamaño del arreglo antes de realizar cualquier otra operación.", "Arreglo no inicializado", JOptionPane.ERROR_MESSAGE);
        }else{
        arreglo = "Arreglo A revertido = [ ";
        for (int i = 0; i < a.length; i++) {
            if( (i == a.length-1) && a[i] != 0){
               arreglo += a[i]; 
            }else{
               if(a[i] != 0){
             arreglo += a[i] +", ";   
            } 
            }   
        }
        arreglo += " ]";
    }
    return arreglo;
    }
    
    public void ordenarYRevertir(){
        if(A == null){
            JOptionPane.showMessageDialog(null, "El arreglo no se ha inicializado. Por favor ingrese el tamaño del arreglo antes de realizar cualquier otra operación.", "Arreglo no inicializado", JOptionPane.ERROR_MESSAGE);
        }else{
        if(A[0] == 0){
            JOptionPane.showMessageDialog(null, "A está vacío.", "Arreglo vacío", JOptionPane.ERROR_MESSAGE);
        }else{
           int[] revertido = A.clone();
            Arrays.sort(revertido);
            JOptionPane.showMessageDialog(null, "Ordenado: "+ imprimirArreglo(revertido));
            JOptionPane.showMessageDialog(null, "Original: "+ imprimirArreglo(A));
        }
        
    }}
    
    public void menu() {
        char opcion = ' ';
        String subMenu = "";
        do {            
            
            subMenu = JOptionPane.showInputDialog("Bienvenido al sistema de gestión de datos de un arreglo \n"
                    + "Seleccione una opción\n"
                    + "a. Leer el tamaño de A.\n"
                    + "b. Ingresar un elemento.\n"
                    + "c. Imprimir A.\n"
                    + "d. Imprimir A de forma inversa.\n"
                    + "e. Imprimir A ordenado.\n"
                    + "x. Salir del submenu Gestión de datos.");
            opcion = subMenu.charAt(0);
        switch(opcion){
            case 'a': 
                int dimension = Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese el tamaño del arreglo A."));
                inicializarArreglo(dimension);
                break;
            case 'b':
                int x = Integer.parseInt(JOptionPane.showInputDialog("Escriba el número a ingresar en el arreglo, tenga en cuenta que el número no puede ser 0."));
                ingresarDatoEnArreglo(x);
                break;
            case 'c':
                JOptionPane.showMessageDialog(null, imprimirArreglo(A));
                break;
            case 'd':
                JOptionPane.showMessageDialog(null, imprimirArregloRevertido(revertirArreglo(A)));
                break;
            case 'e':
                ordenarYRevertir();
                break;
            case 'x': break;
            default: JOptionPane.showMessageDialog(null, "Opción incorrecta. Por favor intente de nuevo", "Error de menu", JOptionPane.ERROR_MESSAGE);
        }
        } while (opcion != 'x');
        
        
    }

    

    
}

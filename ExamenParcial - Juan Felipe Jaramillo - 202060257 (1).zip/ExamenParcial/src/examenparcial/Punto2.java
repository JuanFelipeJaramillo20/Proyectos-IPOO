/*
* Juan Felipe Jaramillo Losada
* Código: 202060257
*/
package examenparcial;

import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class Punto2 {
        
    private int[] frecuenciasArreglo;
    private int[][] matrizEjemplo = new int[5][5];
    
    public void llenarMatrizEjemplo(){
        matrizEjemplo[0][0] = 2;
        matrizEjemplo[0][1] = 5;
        matrizEjemplo[0][2] = 10;
        matrizEjemplo[0][3] = 8;
        matrizEjemplo[0][4] = 9;
        matrizEjemplo[1][0] = 1;
        matrizEjemplo[1][1] = 12;
        matrizEjemplo[1][2] = 5;
        matrizEjemplo[1][3] = 9;
        matrizEjemplo[1][4] = 7;
        matrizEjemplo[2][0] = 5;
        matrizEjemplo[2][1] = 5;
        matrizEjemplo[2][2] = 4;
        matrizEjemplo[2][3] = 12;
        matrizEjemplo[2][4] = 5;
        matrizEjemplo[3][0] = 12;
        matrizEjemplo[3][1] = 10;
        matrizEjemplo[3][2] = 3;
        matrizEjemplo[3][3] = 5;
        matrizEjemplo[3][4] = 9;
        matrizEjemplo[4][0] = 3;
        matrizEjemplo[4][1] = 2;
        matrizEjemplo[4][2] = 6;
        matrizEjemplo[4][3] = 9;
        matrizEjemplo[4][4] = 6;
        
    }
    public int[] frecuencia(int A[][], int x){
        frecuenciasArreglo = new int[A[0].length];
        int contadorFrecuencia = 0;
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i].length; j++) {
                if(A[i][j] == x){
                    contadorFrecuencia++;
                }
                
            }
            frecuenciasArreglo[i] = contadorFrecuencia;
            contadorFrecuencia = 0;
        }
        
        return frecuenciasArreglo;
    }
    
    public String imprimirArreglo(int[] a, int x){
        String arreglo = "";
        for (int i = 0; i < a.length; i++) {
            arreglo += "En la primer columna el valor: " + x + " tiene una frecuencia de : "+ a[i] +"\n";
        } 
        return arreglo;
    }
    public void menu() {
        
        llenarMatrizEjemplo();
        int x = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un valor para el cual calcular la frecuencia."));
        JOptionPane.showMessageDialog(null, "Se calculará la frecuencia con el ejemplo dado en el parcial:");
        JOptionPane.showMessageDialog(null, imprimirArreglo(frecuencia(matrizEjemplo, x), x ));
        
        
    }
    
}

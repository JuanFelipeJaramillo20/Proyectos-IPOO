package mundo;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Sala 
{
	// ATRIBUTOS
	private Silla[][] sillas;
	private Properties misPropiedades;
	

	// TODO: PUNTO 1 (valor 1.0). CREE EL METODO CONSTRUCTOR.
	// METODO CONSTRUCTOR
	public Sala()
	{
		// PARA EL METODO CONSTRUCTOR LOS PASOS SON LOS SIGUIENTES (HAY QUE SEGUIR EL MISMO ORDEN).
		// 1. INSTANCIAR EL OBJETO misPropiedades.
		// 2. HACER EL LLAMADO AL METODO QUE CARGA EL ARCHIVO DE PROPIEDADES.
		// 3. CREAR LA MATRIZ (TOMANDO LA INFORMACIÓN DE FILAS Y COLUMNAS DEL ARCHIVO DE PROPIEDADES).
		// 4. HACER EL LLAMADO AL METODO QUE LEE LA INFORMACION DEL ARCHIVO DE PROPIEDADES Y LA CARGA EN LA MATRIZ.
		
		

		
	}

	// TODO: PUNTO 2 (valor 1.0) . CREE EL METODO cargarArchivoDePropiedades( )throws Exception
	// PRIMER PASO: CARGAR EL ARCHIVO DE PROPIEDADES
	private void cargarArchivoDePropiedades( )throws Exception
	{	
		
		
	}

	// TODO: PUNTO 3 (valor 1.0). CREE EL METODO cargarInformacionALaMatriz()
	// SEGUNDO PASO: PASAR LA INFORMACIÓN DEL ARCHIVO PROPERTIES A LA MATRIZ
	public void cargarInformacionALaMatriz()
	{	
		
		
	}

	// TODO: PUNTO 4 (valor 1.0). CREE EL METODO listarSillas()
	// TERCER PASO: LISTAR LOS ESTUDIANTES QUE ESTAN EN LA MATRIZ
	public void listarSillas()
	{
		
		
	}

	// TODO: PUNTO 5 (valor 1.0). CREE EL METODO listarSillasDisponibles()
	public void listarSillasDisponibles()
	{
		
		
	}


}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Paralelogramo extends Rectangulo{
    
    public Paralelogramo(){
        super();//llama al constructor de la super clase Rectangulo
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Rectangulo extends Cuadrado{
    
    double altura;
    
    public Rectangulo(){
        super();//llama al constructor de la super clase Cuadrado
        altura = 0.0;
    }
    
    public void setAltura(){
        altura = Utilerias.leerDouble("Ingrese la altura:");
    }
    
    public void calcArea(){
        area = base * altura;
    }
    
    public void calcPerimetro(){
        perimetro = base * 2 + altura * 2;
    }
    
    public String toString(){
        return altura + "/" + super.toString();
    }
}


import javax.swing.JOptionPane;

public class Utilerias {
    
    public static double leerDouble(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        double real = Double.parseDouble(ent);
        return real;
    }
    
    public static int leerInt(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        int entero = Integer.parseInt(ent);
        return entero;
    }
}

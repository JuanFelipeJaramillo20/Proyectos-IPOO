
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Estudiante {
    String ape, nom;
    int codigo;
    
    public Estudiante(){
        ape = nom = "";
        codigo = 0;
    }
    
    public Estudiante(String apellido, String nombre, int cod){
        ape = apellido;
        nom = nombre;
        codigo = cod;
    }
    
    public Estudiante(String apellido, String nombre){
        this.ape = apellido;
        nom = nombre;
        codigo = 0;
    }
    
    public Estudiante(String ape){
        this.ape = ape;
        nom = "";
        codigo = 0;
    }
    
    public Estudiante(ArrayList<String> datos){
        ape = datos.get(0);
        nom = datos.get(1);
        codigo = Integer.parseInt(datos.get(2));
    }
    
    public void leerDatos(){
        ape = JOptionPane.showInputDialog("Ingrese el apellido:");
        nom = JOptionPane.showInputDialog("Ingrese el nombre:");
        //codigo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo:"));
        setCodigo();
    }
    
    public void setCodigo(){
        codigo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo:"));
    }
    
    public String toString(){
        return ape + ", " + nom + " " + codigo;
    }
}

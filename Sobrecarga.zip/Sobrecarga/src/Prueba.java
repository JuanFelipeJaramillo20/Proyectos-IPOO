
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Prueba {
    
    public static void main(String[] args) {
        /*Estudiante obj1 = new Estudiante();
        obj1.leerDatos();
        System.out.println(obj1);
                
        Estudiante obj2 = new Estudiante("lasso", "luis", 20);
        System.out.println(obj2);
        
        Estudiante obj3 = new Estudiante("perez", "pepe");
        obj3.setCodigo();
        System.out.println(obj3);
        
        ArrayList<String> datos = new ArrayList<String>();
        datos.add("cardenas");
        datos.add("juan");
        datos.add("40");
        Estudiante obj4 = new Estudiante(datos);
        System.out.println(obj4);   
        */
        JOptionPane.showMessageDialog(null, "mensaje");
        JOptionPane.showMessageDialog(null, "mensaje", "titulo", 
                JOptionPane.ERROR_MESSAGE);
        
        //Image icono = new ImageIcon(getClass().getResource(""));
        JOptionPane.showMessageDialog(null, "mensaje", "titulo", 
                JOptionPane.INFORMATION_MESSAGE, 
                new ImageIcon("src/imagenes/Acrobat-icon.png"));
        
        //------------- leer enteros ------------
        int entero = Utilerias.leerInt("ingrese un numero entero");
        System.out.println(entero);
        
        int enteroEntre = Utilerias.leerInt("ingrese un numero entero entre 5 y 15",
                5, 15);
        System.out.println(enteroEntre);

        
    }
}

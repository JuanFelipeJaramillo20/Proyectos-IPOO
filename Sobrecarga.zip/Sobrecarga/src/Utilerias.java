
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Utilerias {
    
    public static int leerInt(String texto){
        int valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Integer.parseInt(ent);
                    break;
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static int leerInt(String texto, int min, int max){
        int valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Integer.parseInt(ent);
                    if(valor >= min && valor <= max) break;
                    else mensajeError("El valor debe estar entre [" + min + ", " + max + "]");
                    
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static long leerLong(String texto){
        long valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Long.parseLong(ent);
                    break;
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static long leerLong(String texto, long min, long max){
        long valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Long.parseLong(ent);
                    if(valor >= min && valor <= max) break;
                    else mensajeError("El valor debe estar entre [" + min + ", " + max + "]");
                    
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static double leerDouble(String texto){
        double valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Double.parseDouble(ent);
                    break;
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static double leerDouble(String texto, double min, double max){
        double valor = 0;
        do {
            String ent = JOptionPane.showInputDialog(texto);
            if(ent == null){                
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                try {
                    valor = Double.parseDouble(ent);
                    if(valor >= min && valor <= max) break;
                    else mensajeError("El valor debe estar entre [" + min + ", " + max + "]");
                    
                } catch (Exception e) {                    
                    mensajeError("Debe ingresar solo numeros");
                }
            }
        } while (true);
        
        return valor;
    }
    
    public static String leerCadena(String texto){
        String valor = null;
        boolean error = false;
        do {
            error = false;
            valor = JOptionPane.showInputDialog(texto);
            if(valor == null || valor.length() == 0){ 
                error = true;
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                for(int i = 0; i < valor.length(); ){
                    char letra = valor.charAt(i);
                    if(Character.isLetter(letra) || Character.isWhitespace(letra)) i++;
                    else{
                        error = true;
                        mensajeError("Debe ingresar solo letras");
                        break;
                    }
                }                
            }
        } while (error);
        
        return valor;
    }
    
    public static String leerCadena(String texto, int min, int max){
        String valor = null;
        boolean error = false;
        do {
            error = false;
            valor = JOptionPane.showInputDialog(texto);
            if(valor == null || valor.length() == 0){ 
                error = true;
                mensajeAdvertencia("Debe ingresar un valor");
            }else{
                for(int i = 0; i < valor.length(); ){
                    char letra = valor.charAt(i);
                    if(Character.isLetter(letra) || Character.isWhitespace(letra)) i++;
                    else{
                        error = true;
                        mensajeError("Debe ingresar solo letras");
                        break;
                    }
                }
                if(!error){
                    valor = valor.trim(); //quitar espacios en blanco adelante y atras en la cadena
                    if(valor.length() >= min && valor.length() <= max) break;
                    else{
                        error = true;
                        mensajeError("La cadena debe tener entre " + min + " y " + max + " caracteres de longitud");
                    }
                }
            }
        } while (error);
        
        return valor;
    }
    
    public static void mensajeAdvertencia(String texto){
        JOptionPane.showMessageDialog(null, texto,
                        "Error", JOptionPane.WARNING_MESSAGE);
    }
    
    public static void mensajeError(String texto){
        JOptionPane.showMessageDialog(null, texto,
                        "Error", JOptionPane.ERROR_MESSAGE);
    }
}

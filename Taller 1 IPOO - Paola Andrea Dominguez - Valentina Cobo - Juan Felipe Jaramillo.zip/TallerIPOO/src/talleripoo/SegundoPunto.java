
package talleripoo;

import java.util.Arrays;
import javax.swing.JOptionPane;

/*
Integrantes del grupo: 
    Paola Andrea Dominguez - 202059956
    Valentina Cobo - 202060174
    Juan Felipe Jaramillo - 202060257
*/
public class SegundoPunto {
    char abecedario[][];
    int f, c;
    public void tamaño_validar(){
        do { 
            String ent = JOptionPane.showInputDialog("Ingrese tamaño N:");
            f = Integer.parseInt(ent);
            ent = JOptionPane.showInputDialog("Ingrese tamaño M:");
            c = Integer.parseInt(ent);
            abecedario = new char[f][c];
            if (f*c != 28) {
                JOptionPane.showMessageDialog(null,"La multiplicacion de NxM debe dar 28. Inténtalo nuevamente.");
            }
        } while (f*c != 28);
    }
    
  
        
    public void aleatorio_mayus (){
        String mayus = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ ";
             
        if ( abecedario != null){
            for (f = 0; f < abecedario.length; f++) {
            for (c = 0; c < abecedario[0].length; c++) {
              int ale = (int) Math.floor(Math.random()*28);
              abecedario[f][c]= mayus.charAt(ale);
                
            }
            
        }
        }else{
            JOptionPane.showMessageDialog(null, "La matriz no ha sido inicializada. Por favor especifique su dimensión antes de selecciona esta opción.");
        }
          
    }
        
    public void aleatorio_minus (){
        String abc = "abcdefghijklmnñopqrstuvwxyz ";
        
        if (abecedario !=null){
            for (f = 0; f < abecedario.length; f++) {
          for (c = 0; c < abecedario[0].length; c++) {
            int ale = (int) Math.floor(Math.random()*28);
            abecedario[f][c]= abc.charAt(ale);
            }
            
        }
        }else{
            JOptionPane.showMessageDialog(null, "La matriz no ha sido inicializada. Por favor especifique su dimensión antes de selecciona esta opción.");
        }
        
    }
        
 public String imprimirMatrizLetras(){
        String matriz = "";
            for (int i = 0; i < abecedario.length; i++){ 
                matriz += Arrays.toString(abecedario[i]);            
            }
            return matriz;
    }
        
        
    public void menu(){
       int opc;
       do {            
           String ent = JOptionPane.showInputDialog(
                
                "1. Introducir tamaño matriz. (El resultado de columnas*filas debe ser igual a 28)\n" +
                "2. Rellenar con mayúsculas.\n" + 
                "3. Rellenar con minúsculas.\n" +
                "4. Visualizar.\n" +        
                "0. Salir.");
            
            opc = Integer.parseInt(ent);
            switch(opc){
                case 1: tamaño_validar(); 
                case 2: aleatorio_mayus(); break;
                case 3: aleatorio_minus(); break;
                case 4: JOptionPane.showMessageDialog(null, imprimirMatrizLetras()); break;
                case 0: break;
                default: JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        } while (opc != 0);
    }
        
       
    public static void main(String[] args) {
      SegundoPunto obj = new SegundoPunto();
      obj.menu();
    }
}

package talleripoo;

import javax.swing.JOptionPane;

/*
Integrantes del grupo: 
    Paola Andrea Dominguez - 202059956
    Valentina Cobo - 202060174
    Juan Felipe Jaramillo - 202060257
*/
public class TallerIPOO {
    PrimerPunto llamado= new PrimerPunto();
    SegundoPunto llamado1= new SegundoPunto();
    TercerPunto llamado2= new TercerPunto();
    public void MenuPrincipal(){
        int opc;
        do {
            String ent = JOptionPane.showInputDialog(
                "Señor usuario, bienvenido a al menú principal. \n"
                + "Elija una opción que quieras ejecutar.\n" +
                "1. Primer punto del taller.\n" +
                "2. Segundo punto (generador de abecedario).\n" + 
                "3. Métodos de ordenamiento.\n" +       
                "0. Salir.");
            opc= Integer.parseInt(ent);
            switch(opc){
                case 1: llamado.Menu(); break;
                case 2: llamado1.menu(); break;
                case 3: llamado2.Salida();break;
                case 0: break;
            }
        } while (opc != 0);
        
    }
    
    public static void main(String[] args) {
      TallerIPOO obj= new TallerIPOO();
      obj.MenuPrincipal();
    }
    
}

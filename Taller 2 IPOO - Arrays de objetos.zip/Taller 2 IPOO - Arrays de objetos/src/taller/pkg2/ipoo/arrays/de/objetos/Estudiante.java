package taller.pkg2.ipoo.arrays.de.objetos;
import javax.swing.JOptionPane;

/*
 * Integrantes del grupo: 
 * Paola Andrea Dominguez - 202059956
 * Valentina Cobo - 202060174
 * Juan Felipe Jaramillo - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
public class Estudiante {
    
    String nombre, apellido;
    int codigo;
    String planAcademico;
    double parcial1, parcial2, tf;
    private double def;
    
    public Estudiante(){
        nombre = apellido = "";
        codigo = 0;
        parcial1 = parcial2 = tf = def = 0.0;
    }
     
    public String getPlanAcademico() {
        return planAcademico;
    }

    public void setPlanAcademico() {
        planAcademico = Utilerias.leerPlanAcademico();
    }
    
    public void setNombre(){
        nombre = JOptionPane.showInputDialog("Ingrese el nombre:");
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setApellido(){
        apellido = JOptionPane.showInputDialog("Ingrese el apellido:");
    }
    
    public String getApellido(){
        return apellido;
    }
    
    public void setCodigo(){
        //String ent = JOptionPane.showInputDialog("Ingrese el codigo:");
        //codigo = Integer.parseInt(ent);
        codigo = Utilerias.leerInt("Ingrese el codigo:");
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public void setParcial1(){
        parcial1 = Utilerias.leerDouble("Ingrese el pacial 1");
    }
    
    public double getParcial1(){
        return parcial1;
    }
    
    public void setParcial2(){
        parcial2 = Utilerias.leerDouble("Ingrese el pacial 2");
    }
    
    public double getParcial2(){
        return parcial2;
    }
    
    public void setTF(){
        tf = Utilerias.leerDouble("Ingrese el TF");        
    }
    
    public double getTF(){
        return tf;
    }
    
    public void calcDef(){
        def = parcial1*0.3 + parcial2*0.3 + tf*0.4;
    }
    
    public double getDef(){
        return def;
    }
    
    public String toString(){
        return apellido + ", " + nombre + "\n" +
                "Código de estudiante: " + codigo + "\n" +
                "Código de carrera: " + planAcademico + "\n" +
                "Parcial 1: " + parcial1 + "\n" +
                "Parcial 2: " +parcial2 + "\n" +
                "Trabajo Final: " + tf + "\n" +
                "Nota Definitiva: " + def;
    }
}
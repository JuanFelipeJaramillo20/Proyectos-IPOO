/*
 * Integrantes del grupo: 
 * Paola Andrea Dominguez - 202059956
 * Valentina Cobo - 202060174
 * Juan Felipe Jaramillo - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package taller.pkg2.ipoo.arrays.de.objetos;

import javax.swing.JOptionPane;


public class Taller2IPOOArraysDeObjetos {

    
    Estudiante listado[];
    
    public void leerTamano(){
        int tam = Utilerias.leerInt("Ingrese la cantidad de estudiantes del curso:");
        listado = new Estudiante[tam];
    }
     
    public void ingresarDatos(){
        for (int i = 0; i < listado.length; i++) {
            listado[i] = new Estudiante();
            JOptionPane.showMessageDialog(null, "Datos del estudiante # " + (i+1));
            listado[i].setApellido();
            listado[i].setNombre();
            listado[i].setCodigo();
            listado[i].setPlanAcademico();
            
        }
    }
    
    public void ingresarNotas(){
        for (int i = 0; i < listado.length; i++) {
            Estudiante estudiante = listado[i];
            JOptionPane.showMessageDialog(null, "Notas del estudiante # " + (i+1) );
            listado[i].setParcial1();
            listado[i].setParcial2();
            listado[i].setTF();
            listado[i].calcDef();
        }
    }
    
    public void modificarNotasDeEstudiante(int codigo){
        for (int i = 0; i < listado.length; i++) {
            if (listado[i].getCodigo() == codigo) {
                JOptionPane.showMessageDialog(null, "Modificando notas del estudiante " + listado[i].getNombre() + " " + listado[i].getApellido() );
                listado[i].setParcial1();
                listado[i].setParcial2();
                listado[i].setTF();
                listado[i].calcDef();
            }
            
        }
    }
    
    public Estudiante buscar_x_cod(int codigo){
        Estudiante obj = null;
        for (int i = 0; i < listado.length; i++) {
            Estudiante tmp = listado[i];
            if(tmp.getCodigo() == codigo){
                obj = tmp;
                break;
            }
        }
        return obj;
    }
    
    public void buscar(){
        int codigo = Utilerias.leerInt("Ingrese el codigo a buscar:");
        Estudiante est = buscar_x_cod(codigo);
        if(est == null){
            JOptionPane.showMessageDialog(null, 
                    "El estudiante con codigo " + codigo + " no existe");
        }else{
            JOptionPane.showMessageDialog(null, est.toString());
        }
    }
    
    public void imprimirListadoGeneral(){
        String listaEstudiantes = "";
        for (int i = 0; i < listado.length; i++) {
            listaEstudiantes += listado[i].toString() + "\n";
        }
        JOptionPane.showMessageDialog(null, listaEstudiantes);
    }

    public void imprimirListadoPorPlanAcademico(String codigoPlan){
        String listaEstudiantes = "";
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getPlanAcademico().equals(codigoPlan)){
                listaEstudiantes += listado[i].toString() + "\n";
            }
        }
        if(listaEstudiantes.equals("")){
            JOptionPane.showMessageDialog(null, "No hay ningún estudiante del programa académico ingresado");
        }else{
            JOptionPane.showMessageDialog(null, listaEstudiantes);
        }
        
    }
    
    public void acercaDe(){
        JOptionPane.showMessageDialog(null, "Autor No. 1:\n"
                + "Jaramillo Losada, Juan Felipe\n"
                + "juan.felipe.jaramillo@correounivalle.edu.co\n"
                + "Semestre No: 2\n"
                + "Autor No. 2:\n"
                + "Bastidas Cobo, Valentina\n"
                + "valentina.cobo@correounivalle.edu.co\n"
                + "Semestre No. 2\n"
                + "Autor No. 3:\n"
                + "Dominguez Velez, Paola Andrea\n"
                + "paola.dominguez@correounivalle.edu.co\n"
                + "Semestre No. 2");
    }
    
    public int consultarCantidadAprobados(){
        int aprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() >= 3.0){
                aprobados++;
            }
            
        }
        return aprobados;
    }
    
    public int consultarCantidadReprobados(){
        int reprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() < 3.0){
                reprobados++;
            }
            
        }
        return reprobados;
    }
    
    public double calcularPromedioGeneral(){
        double promedio = 0.0;
        for (int i = 0; i < listado.length; i++) {
            promedio += listado[i].getDef();
        }
        promedio /= listado.length;
        return promedio;
    }
    
    public double calcularPromedioAprobados(){
        double promedio = 0.0;
        int contadorAprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() >= 3.0){
                promedio += listado[i].getDef();
                contadorAprobados++;
            }
        }
        promedio /= contadorAprobados;
        return promedio;
    }
    
    public double calcularPromedioReprobados(){
        double promedio = 0.0;
        int contadorReprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() < 3.0){
                promedio += listado[i].getDef();
                contadorReprobados++;
            }
        }
        promedio /= contadorReprobados;
        return promedio;
    }
    
    public int cantidadAprobados(){
        int cantidadAprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() >= 3.0){
                cantidadAprobados++;
            }            
        }
        return cantidadAprobados;
    }
    
    public int cantidadReprobados(){
        int cantidadReprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if(listado[i].getDef() >= 3.0){
                cantidadReprobados++;
            }            
        }
        return cantidadReprobados;
    }
    
    public int cantidadAprobadosPorPlan(String codigoPlan){
        int cantidadAprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if( listado[i].getPlanAcademico().equals(codigoPlan) && listado[i].getDef() >= 3.0){
                cantidadAprobados++;
            }
        }
        return cantidadAprobados;
    }
    
    public int cantidadReprobadosPorPlan(String codigoPlan){
        int cantidadReprobados = 0;
        for (int i = 0; i < listado.length; i++) {
            if( listado[i].getPlanAcademico().equals(codigoPlan) && listado[i].getDef() < 3.0){
                cantidadReprobados++;
            }
        }
        return cantidadReprobados;
    }
    
    public void menu(){
        int opc;
        do{
            opc = Utilerias.leerInt("Menu principal\n\n" + 
                    "1. Leer cantidad de estudiantes\n" +
                    "2. Ingresar datos\n" + 
                    "3. Ingresar notas\n" + 
                    "4. Modificar notas de un estudiante\n" +
                    "5. Submenu listados\n" + 
                    "6. Submenu consultas\n"
                    + "7. Acerca de... \n"
                    + "8. Salir de la aplicación");
            switch(opc){
                case 1: leerTamano(); break;
                case 2: ingresarDatos(); break;
                case 3: ingresarNotas(); break;
                case 4: 
                    int codigo = Utilerias.leerInt("Ingrese el código del estudiante del cual quiere modificar las notas");
                    modificarNotasDeEstudiante(codigo); break;
                case 5:
                    char opcionSubMenuListados = ' ';
                    do {                        
                     opcionSubMenuListados = Utilerias.leerChar("Submenu Listados\n\n"
                             + "a) Listado General\n"
                             + "b) Listado por plan\n"
                             + "c) Volver al menú principal");
                     switch(opcionSubMenuListados){
                        case 'a':
                            imprimirListadoGeneral(); break;
                        case 'b':
                            String codigoPlan = Utilerias.leerPlanAcademico();
                            imprimirListadoPorPlanAcademico(codigoPlan); break;
                        case 'c': break;
                    }
                    } while (opcionSubMenuListados != 'c');
                    break;
                case 6:
                    char opcionSubMenuConsultas = ' ';
                    do {                        
                    opcionSubMenuConsultas = Utilerias.leerChar("Submenu Consultas\n\n"
                            + "a) Consultar datos por código estudiantil\n"
                            + "b) Consultar cantidad de estudiantes que aprobaron y reprobaron\n"
                            + "c) Nota promedio general, nota promedio de los que aprobaron y nota promedio de los que reprobaron\n"
                            + "d) Cantidad de estudiantes que aprobaron y reprobaron por plan\n"
                            + "e) Volver al menú principal");
                    switch(opcionSubMenuConsultas){
                        case 'a':
                            int codigoEst = Utilerias.leerInt("Inserte el código del estudiante a buscar");
                            JOptionPane.showMessageDialog(null, buscar_x_cod(codigoEst).toString());
                            break;
                        case 'b':
                            JOptionPane.showMessageDialog(null, "Estudiantes aprobados: " + consultarCantidadAprobados() + "\n" + "Estudiantes reprobados: " + consultarCantidadReprobados()); 
                            break;
                        case 'c':
                            JOptionPane.showMessageDialog(null, "Promedio General: " + calcularPromedioGeneral() + "\n"
                            + "Promedio de los estudiantes aprobados: " + calcularPromedioAprobados() + "\n"
                            + "Promedio de los estudiantes reprobados: " + calcularPromedioReprobados());
                            break;
                        case 'd':
                            String codigoPlan = Utilerias.leerPlanAcademico();
                            JOptionPane.showMessageDialog(null, "Estudiantes que aprobaron el curso: " + cantidadAprobadosPorPlan(codigoPlan) + "\n"
                                    + " Estudiantes que reprobaron el curso: " + cantidadReprobadosPorPlan(codigoPlan));
                            break;
                        case 'e': break;
                    }
                    } while (opcionSubMenuConsultas != 'e');
                    break;
                case 7:
                    acercaDe(); break;
                case 8: break;
            }
        }while(opc != 8);
    }
    
    public static void main(String[] args) {
        Taller2IPOOArraysDeObjetos obj = new Taller2IPOOArraysDeObjetos();
        obj.menu();
        
    }

    
}

package taller.pkg2.ipoo.arrays.de.objetos;
import javax.swing.JOptionPane;
/*
 * Integrantes del grupo: 
 * Paola Andrea Dominguez - 202059956
 * Valentina Cobo - 202060174
 * Juan Felipe Jaramillo - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
public class Utilerias {
    
    public static String[] planesAcademicos = {"3743 - Ingeniería de Sistemas",
        "3845 - Administración de empresas", "3841 - Contaduría pública",
        "574 - Trabajo social", "3753 - Ingeniería de alimentos",
        "2724 - Tecnología en desarrollo de software",
        "2710 - Tecnología en electrónica"};
    
    public static double leerDouble(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        double real = Double.parseDouble(ent);
        return real;
    }
    
    public static int leerInt(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        int entero = Integer.parseInt(ent);
        return entero;
    }
    
    public static char leerChar(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        char caracter = ent.charAt(0);
        return caracter;
    }
    
    public static String leerPlanAcademico(){
        String plan = (String) JOptionPane.showInputDialog(null,"Selecciona un plan académico","Plan académico",JOptionPane.QUESTION_MESSAGE, null,planesAcademicos, planesAcademicos[0]);
        return plan;
    }
}
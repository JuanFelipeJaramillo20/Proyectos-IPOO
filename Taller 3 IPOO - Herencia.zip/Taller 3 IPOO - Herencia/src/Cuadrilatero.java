/* * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Cuadrilatero extends Poligono {
    double diagonal1;
    double diagonal2;

    public Cuadrilatero() {
        super();
        lados = new double[4];
        diagonal1 = diagonal2 = 0.0;
    }
    
    public void setDiagonal1(){
        diagonal1 = Utilerias.leerDouble("Ingrese el valor de la diagonal 1:");
    }
    
    public void setDiagonal2(){
        diagonal2 = Utilerias.leerDouble("Ingrese el valor de la diagonal 2:");
    }

    @Override
    public String toString() {
        return super.toString() + ", diagonal1=" + diagonal1 + ", diagonal2=" + diagonal2;
    }

    
    
}

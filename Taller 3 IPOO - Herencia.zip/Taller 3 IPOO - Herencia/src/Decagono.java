/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Decagono  extends Poligono{
    
    public double lado4, lado5, lado6, lado7, lado8, lado9, lado10;

    public Decagono() {
        super();
        lados = new double[10];
    }

   
    public void calcularArea(){
        area = 10 * lados[0] * apotema;
    }
    
    public void calcularPerimetro(){
        perimetro = lados[0] + lados[1] + lados[2] + lados[3] + lados[4] + lados[5] + lados[6] + lados[7] + lados[8] + lados[9];
    }

}

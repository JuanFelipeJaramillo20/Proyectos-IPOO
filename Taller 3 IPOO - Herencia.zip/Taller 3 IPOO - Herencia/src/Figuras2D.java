
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public abstract class Figuras2D {
    
    double area, perimetro;
    
    public Figuras2D(){
        area = perimetro = 0.0;
    }
    
    public double getArea(){
        return area;
    }
    
    public double getPerimetro(){
        return perimetro;
    }

    @Override
    public String toString() {
        return ", area=" + area + ", perimetro=" + perimetro;
    }
    
    
    
}

    /*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Hexagono extends Poligono {
    
    public double lado4;
    public double lado5;
    public double lado6;

    public Hexagono() {
        super();
        lados = new double[6];
    }
    
    public void calcularArea(){
        area = ((perimetro * apotema) / 2);
    }
    
    public void calcularPerimetro(){
        perimetro =  lados[0] + lados[1] + lados[2] + lados[3] + lados[4] + lados[5];
    }    
    
}

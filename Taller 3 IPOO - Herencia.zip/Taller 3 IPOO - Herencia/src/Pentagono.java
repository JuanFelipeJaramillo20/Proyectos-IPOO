/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Pentagono extends Poligono{

    public Pentagono() {
        super();
        lados = new double[5];
    }
    
    public void calcularArea(){
        area = (5 * Math.pow(lados[0], 2))/ (4* Math.tan(Math.PI / 5)); 
    }
    
    public void calcularPerimetro(){
        perimetro = lados[0] + lados[1] + lados[2] + lados[3] + lados[4];
    }

    
    
    
}

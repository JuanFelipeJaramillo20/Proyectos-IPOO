
import java.util.Arrays;

        /*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Poligono extends Figuras2D {
    
    public double[] lados;
    double apotema;
    
    public Poligono(){
      apotema = 0;  
    }
    
    public void setLados(){
        for (int i = 0; i < lados.length; i++) {
            lados[i] = Utilerias.leerDouble("Ingrese el valor del lado No" + (i+1));
            
        }
    }
    
    public void setApotema(){
        apotema = Utilerias.leerDouble("Ingrese el valor de la apotema:");
    }

    @Override
    public String toString() {
        return "Lados: " +Arrays.toString(lados) + ", apotema=" + apotema + super.toString();
    }
    
    
}

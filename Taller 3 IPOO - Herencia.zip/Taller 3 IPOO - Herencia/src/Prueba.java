/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Prueba {
    
    public void testCuadrado(){
        Cuadrado objC = new Cuadrado();
        objC.setLados();
        objC.calcArea();
        objC.calcPerimetro();
        System.out.println(objC);
    }
    
    public void testRectangulo(){
        Rectangulo objR = new Rectangulo();
        objR.setBase();
        objR.setAltura();
        objR.calcArea();
        objR.calcPerimetro();
        System.out.println(objR);
    }
    
    public void testParalelogramo(){
        Paralelogramo objP = new Paralelogramo();
        objP.setBase();
        objP.setAltura();
        objP.calcArea();
        objP.calcPerimetro();
        System.out.println(objP);
    }
    
    public void testCirculo(){
        Circulo objC = new Circulo();
        objC.setRadio();
        objC.calcArea();
        objC.calcPerimetro();
        System.out.println(objC);
    }
    
    public void testRombo(){
        Rombo objR = new Rombo();
        objR.setLados();
        objR.setDiagonal1();
        objR.setDiagonal2();
        objR.setApotema();
        objR.calcularArea();
        objR.calcularPerimetro();
        System.out.println(objR);
    }
    
    public void testTrapecio(){
        Trapecio objT = new Trapecio();
        objT.setLados();
        objT.setAltura();
        objT.calcularArea();
        objT.calcularPerimetro();
        System.out.println(objT);
    }
    
    public void testPentagono(){
        Pentagono objP = new Pentagono();
        objP.setLados();
        objP.calcularArea();
        objP.calcularPerimetro();
        System.out.println(objP);
    }
    
    public void testHexagono(){
        Hexagono objH = new Hexagono();
        objH.setLados();
        objH.setApotema();
        objH.calcularPerimetro();
        objH.calcularArea();
        System.out.println(objH);
    }
    
    public void testDecagono(){
        Decagono objD = new Decagono();
        objD.setLados();
        objD.setApotema();
        objD.calcularArea();
        objD.calcularPerimetro();
        System.out.println(objD);
    }
            
    
    public static void main(String[] args) {
        Prueba p = new Prueba();
        p.testCuadrado();
        p.testRectangulo();
        p.testParalelogramo();
        p.testCirculo();
        p.testDecagono();
        p.testHexagono();
        p.testRombo();
        p.testTrapecio();
        p.testPentagono();
    }
}

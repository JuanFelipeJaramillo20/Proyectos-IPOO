
public class Rectangulo extends Cuadrilatero{
    
    double altura;
    double base;
    
    public Rectangulo(){
        super();//llama al constructor de la super clase Cuadrado
        altura = 0.0;
        base = 0;
    }
    
    public void setAltura(){
        altura = Utilerias.leerDouble("Ingrese la altura:");
    }
    
    public void calcArea(){
        area = base * altura;
    }
    
    public void calcPerimetro(){
        perimetro = base * 2 + altura * 2;
    }

    public void setBase(){
        lados[0] = Utilerias.leerDouble("Ingrese el valor de la base del rectángulo:");
    }

    @Override
    public String toString() {
        return super.toString() + ", altura=" + altura + ", base=" + lados[0];
    }
    
    
}

/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Rombo extends Cuadrilatero {
    

    public Rombo() {
        super();
    }
    
    public void calcularArea(){
        area = (diagonal1 * diagonal2) / 2;
    }
    
    public void calcularPerimetro(){
        perimetro = 4*lados[0];
    }
    
    
    
}

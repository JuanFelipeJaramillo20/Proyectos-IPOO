/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */

/**
 *
 * @author juanf
 */
public class Trapecio extends Cuadrilatero{
    
    double altura;

    public Trapecio() {
        super();
        altura = 0;
    }
    
    public void setAltura(){
        altura = Utilerias.leerDouble("Ingrese la altura del trapecio:");
    }
    
    public void calcularArea(){
        area = ((lados[0] + lados[1]) * altura) / 2;
    }
    
    public void calcularPerimetro(){
        perimetro = lados[0] + lados[1] + lados[2] + lados[3];
    }

    @Override
    public String toString() {
        return super.toString() + ", altura=" + altura;
    }

    
    
}

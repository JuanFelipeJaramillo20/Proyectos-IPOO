/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talleripoo;
import java.text.DecimalFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
/**
 *
 * @author Andom
 */
public class PrimerPunto {
    
    String BásculaCamiones[][]= new String [50] [6];
    int RegistroActuales= 0;
    
    public void IngresarPesaje(){
        if(RegistroActuales == BásculaCamiones.length){
           JOptionPane.showMessageDialog(null, "La matriz está llena. No se pueden almacenar más datos.");
           } else{
                String placa_vehiculo= JOptionPane.showInputDialog("Ingrese la placa del vehículo. ");
                String peso;
                    do {                        
                        peso= JOptionPane.showInputDialog("Ingrese el peso de carga. ");
                        if(Integer.parseInt(peso) < 0){
                            JOptionPane.showMessageDialog(null, "Una cantidad peso nunca puede ser negativa. Ingresa nuevamente el dato.", "ERROR", 0);
                           }
                    } while (Integer.parseInt(peso) < 0);
               
                String destino;
                boolean salir= false;
                    do {
                        destino= JOptionPane.showInputDialog("Ingrese el destino del vehículo. \n" +
                                "1. Buenaventura. \n" +
                                "2. Bogotá. \n" +
                                "3. Barranquilla. \n");
                        if(Integer.parseInt(destino) == 1 || Integer.parseInt(destino) == 2 || Integer.parseInt(destino) == 3){
                            salir= true;
                            }else{
                                JOptionPane.showMessageDialog(null, "Introduzca únicamente algunas de las opciones que se le ofrece.", "ERROR", 0);
                              }
                    } while (!salir);
                    
                String dia;
                    do {                        
                        dia= JOptionPane.showInputDialog("Ingrese el día del viaje. ");
                        if(Integer.parseInt(dia) < 0)
                                JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. Introduzca un día no negativo.", "ERROR", 0);
                    } while (Integer.parseInt(dia) < 0);
                
                String mes;
                    do {                        
                        mes= JOptionPane.showInputDialog("Ingrese el mes en el cuál se realiza el viaje (como número). ");
                        if(Integer.parseInt(mes) > 12){
                            JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. Realice lo que se le indica, los meses númericamente no sobrepasan el mes 12.", "ERROR", 0);
                          }else if(Integer.parseInt(mes) < 0){
                            JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. El mes no puede ingresarse con valor negativo.", "ERROR", 0);
                            }
                    } while (Integer.parseInt(mes) < 0 || Integer.parseInt(mes) > 12);
                          
                Calendar cal= Calendar.getInstance();
                int anioActual= cal.get(Calendar.YEAR);
                String anio;
                    do {
                        anio= JOptionPane.showInputDialog("Ingrese el año en el cuál se realiza el viaje. ");
                        if(Integer.parseInt(anio) < 0){
                            JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. No ingrese cantidad negativa.", "ERROR", 0); 
                         } else if(Integer.parseInt(anio) > anioActual){
                            JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. No ingrese un año superior al actual.", "ERROR", 0); 
                            }
                    } while (Integer.parseInt(anio) < 0 || Integer.parseInt(anio) > anioActual);
                    
               AsignarMat(placa_vehiculo, peso , destino , dia, mes, anio);
            }
    }
    
    public void AsignarMat(String placaVehiculo, String peso, String destino, String dia, String mes, String anio){
        
        for (int fila = 0; fila < BásculaCamiones.length; fila++) {
            if(BásculaCamiones[fila][0] == null){
                BásculaCamiones[fila][0]= placaVehiculo;
                BásculaCamiones[fila][1]= peso;
                BásculaCamiones[fila][2]= destino;
                BásculaCamiones[fila][3]= dia;
                BásculaCamiones[fila][4]= mes;
                BásculaCamiones[fila][5]= anio;
                RegistroActuales++;
                break;
            }
        }                   
    }
    
    public void imprimirMatriz(String mat[][]){
	String salida = "";
	for(int f = 0; f < mat.length; f++){
		salida+="        Datos viaje " + (f+1) + "\n" +
                        "Placa del camión: " + mat[f][0] + "\n" +
                        "Peso en toneladas del viaje: " + mat[f][1] + "\n" +
                        "Destino: " + mat[f][2] + "\n" +
                        "Dia: " + mat[f][3] + "\n" +
                        "Mes: " + mat[f][4] + "\n" +
                        "Año: " + mat[f][5] + "\n" + "\n";
	}
        System.out.println(salida);
	JOptionPane.showMessageDialog(null, salida);
	}
    
    public int PesoTotal(){
        int peso= 0;
        for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][1] != null){
                peso+= Integer.parseInt(BásculaCamiones[i][1]);
            } 
        }
        return peso;
    }
    public int CantDestino1(){
        int Destino1=0;
         for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][2] != null & BásculaCamiones[i][2].equals("1")){
                Destino1++;
            }  
        }
         return Destino1;
    }
    
    public int CantDestino2(){
        int Destino2=0;
         for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][2] != null & BásculaCamiones[i][2].equals("2")){
                Destino2++;
            }  
        }
         return Destino2;
    }
    
    public int CantDestino3(){
        int Destino3=0;
         for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][2] != null & BásculaCamiones[i][2].equals("3")){
                Destino3++;
            }  
        }
         return Destino3;
    }
    public String PesoPromedio(){
        int PesoDestino1= 0; int PesoDestino2=0; int PesoDestino3=0;
        double PromedioDestino1, PromedioDestino2, PromedioDestino3;
        String Salida= "";
        
        for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][2].equals("1")){
                PesoDestino1+= Integer.parseInt(BásculaCamiones[i][1]);
            }
            else if(BásculaCamiones[i][2].equals("2")){
                PesoDestino2+= Integer.parseInt(BásculaCamiones[i][1]);
            } 
            else{
               PesoDestino3+= Integer.parseInt(BásculaCamiones[i][1]); 
            }  
        }
        DecimalFormat formato= new DecimalFormat("#.#");
        PromedioDestino1=  (double) (PesoDestino1)/ (double) (CantDestino1());
        PromedioDestino2=  (double) (PesoDestino2)/ (double) (CantDestino2());
        PromedioDestino3=  (double) (PesoDestino3)/ (double) (CantDestino3());
        
        Salida+= "- Peso promedio de viajes a Buenaventura: "+ formato.format(PromedioDestino1) + " toneladas \n"
                + "- Peso promedio de viajes a Bogotá: " + formato.format(PromedioDestino2) + " toneladas \n"
                + "- Peso promedio de viajes a Barranquilla: " + formato.format(PromedioDestino3) + " toneladas";
        
        return Salida;
    }
    
    public void IntDatos(){
        String día;
        do {
           día= JOptionPane.showInputDialog("Ingrese la fecha y el destino del viaje que quiere consultar. \n" +
                "Primero introduzca el día."); 
           if(Integer.parseInt(día) < 0)
              JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. Introduzca un día no negativo.", "ERROR", 0);
        } while (Integer.parseInt(día) < 0);
         
        String mes; 
        do {
           mes= JOptionPane.showInputDialog("Ahora introduzca el mes. "); 
           if(Integer.parseInt(mes) > 12){
              JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. Realice lo que se le indica, los meses númericamente no sobrepasan el 12(Diciembre).", "ERROR", 0);
                }
           else if(Integer.parseInt(mes) < 0){
              JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. El mes no puede ingresarse con valor negativo.", "ERROR", 0);
                }
        } while (Integer.parseInt(mes) < 0 || Integer.parseInt(mes) > 12);
        
        Calendar cal= Calendar.getInstance();
        int anioActual= cal.get(Calendar.YEAR);
        String anio;
        do {
            anio= JOptionPane.showInputDialog("Introduzca el año. ");
            if(Integer.parseInt(anio) < 0){
                JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. Ingrese una cantidad válida.", "ERROR", 0); 
                } 
            else if(Integer.parseInt(anio) > anioActual){
                JOptionPane.showMessageDialog(null, "Vuelve a intentarlo. No ingrese un año superior al actual.", "ERROR", 0); 
                }
        } while (Integer.parseInt(anio) < 0 || Integer.parseInt(anio) > anioActual);
        String dest;
        boolean salir= false;
        do {
          dest= JOptionPane.showInputDialog("Por último ingrese el destino del viaje a consultar. (Recuerde: 1- Buenaventura, 2- Bogotá, 3- Barranquilla )"); 
          if(Integer.parseInt(dest) == 1 || Integer.parseInt(dest) == 2 || Integer.parseInt(dest) == 3){
            salir= true;
            }
          else{
              JOptionPane.showMessageDialog(null, "Introduzca únicamente algunas de las opciones que se le ofrece.", "ERROR", 0);
                }
        } while (!salir);
        
    BuscarViaje(dest, día, mes, anio);
    }
    
    public void BuscarViaje(String dest, String dia, String mes, String anio){
        String destSalida= ""; String dataSalida="";
        int contadorViajes=0; 
        int posEncontrado=-1; 
        for (int i = 0; i < RegistroActuales; i++) {
            if(BásculaCamiones[i][2].equals(dest) & BásculaCamiones[i][3].equals(dia) & BásculaCamiones[i][4].equals(mes) & BásculaCamiones[i][5].equals(anio)){
                contadorViajes++;
                posEncontrado= i;
            }
        }
        
        if(dest.equals("1")){
            destSalida= "Buenaventura";
        } else if(dest.equals("2")){
            destSalida= "Bogotá";
        } else{
            destSalida= "Barranquilla";
        }
        
        if(posEncontrado >= 0){
            dataSalida= "Placa del camión: " + BásculaCamiones[posEncontrado][0] + "\n" +
                      "Peso: " + BásculaCamiones[posEncontrado][1] + " toneladas" ;
            
        } else{
            dataSalida= "Placa del camión:  No hay información" + "\n" +
                        "Peso:  No hay información";
        }
        
        JOptionPane.showMessageDialog(null, "En la fecha " + dia + "/" + mes + "/" + anio + "," +
                " con destino a " +  destSalida + " se realizó " + contadorViajes + " viaje(s). \n" + "Con sus siguientes datos registrados: \n" +
                dataSalida);
    }
    
    public void Menu(){
        char opcion;
        do {            
            String ent= JOptionPane.showInputDialog("Bienvenido a su menú. Estas opciones tenemos disponibles para tí: \n" +
                    "a. Introducir datos del pesaje. \n" +
                    "b. Consultar el total de cantidad de viajes realizados  y su peso. \n" + 
                    "c. Consultar cantidad de viajes realizados a cada destino y su peso promedio. \n" +
                    "d. Consultar viaje. \n" +
                    "x. Visualizar datos. \n" +
                    "e. Salir.");
            opcion= ent.charAt(0);
            opcion= Character.toLowerCase(opcion);
            switch(opcion){
                case 'a': IngresarPesaje(); break;
                case 'b':int PesoTotal= PesoTotal(); 
                         //No se declaró una variable que fuera la cantidad de viajes realizados, ya que RegistroActuales me almacena cada vez que un usuario ingresa un pesaje, la cantidad de un viaje.
                         JOptionPane.showMessageDialog(null, "Hasta el día de hoy se han realizado: " + RegistroActuales + " viaje(s), con un total de " +
                                PesoTotal + " toneladas de mercancía.");
                         ; break;
                         
                case 'x': imprimirMatriz(BásculaCamiones); break;
                
                case 'c': int Destino1= CantDestino1();
                          int Destino2= CantDestino2();
                          int Destino3= CantDestino3();
                          String salida= PesoPromedio();
                          JOptionPane.showMessageDialog(null, "Hasta el día de hoy se han realizado en: \n" +  "Buenaventura: " + Destino1 + " viaje(s). \n" +
                                  "Bogotá: " + Destino2 + " viaje(s). \n" +
                                  "Barranquilla: " + Destino3 + " viaje(s). \n" +
                                  "Con sus siguientes promedios: \n" + salida);
                          break;
                case 'd': IntDatos(); break;
                case 'e': break;
                default: JOptionPane.showMessageDialog(null, "Error. Opción ingresada incorrecta.", "ERROR", 0);
            } //imprimirMatriz("BásculaCamiones", BásculaCamiones)
        } while (opcion!='e');
    }
    
    public static void main(String[] args) {
        PrimerPunto obj= new PrimerPunto();
        obj.Menu();
    }
}



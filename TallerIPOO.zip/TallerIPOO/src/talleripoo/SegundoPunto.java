/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talleripoo;

import javax.swing.JOptionPane;

/**
 *
 * @author Andom
 */
public class SegundoPunto {
    char abecedario[][];
    int f, c;
    public void tamaño_validar(){
        do { 
            String ent = JOptionPane.showInputDialog("Ingrese tamaño N:");
            f = Integer.parseInt(ent);
            ent = JOptionPane.showInputDialog("Ingrese tamaño M:");
            c = Integer.parseInt(ent);
            abecedario = new char[f][c];
            if (f*c != 28) {
                JOptionPane.showMessageDialog(null,"La multiplicacion de NxM debe dar 28. Inténtalo nuevamente.");
            }
        } while (f*c != 28);
    }
    
  
        
    public void aleatorio_mayus (){
        String mayus = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ ";
             
          for (f = 0; f < abecedario.length; f++) {
            for (c = 0; c < abecedario[0].length; c++) {
              int ale = (int) Math.floor(Math.random()*28);
              abecedario[f][c]= mayus.charAt(ale);
                
            }
            
        }
    }
        
    public void aleatorio_minus (){
        String abc = "abcdefghijklmnñopqrstuvwxyz ";
             
        for (f = 0; f < abecedario.length; f++) {
          for (c = 0; c < abecedario[0].length; c++) {
            int ale = (int) Math.floor(Math.random()*28);
            abecedario[f][c]= abc.charAt(ale);
            }
            
        }
    }
        
    public void imprimir (){
            
        for ( f = 0; f < abecedario.length; f++) {
            for (c = 0; c < abecedario[0].length; c++) {
                System.out.print(abecedario[f][c] + " "); 
            }
            System.out.println();
        }
        
    }
        
        
    public void menu(){
       int opc;
       do {            
           String ent = JOptionPane.showInputDialog(
                
                "1. Introducir tamaño matriz.\n" +
                "2. Rellenar con mayúsculas.\n" + 
                "3. Rellenar con minúsculas.\n" +
                "4. Visualizar.\n" +        
                "0. Salir.");
            
            opc = Integer.parseInt(ent);
            switch(opc){
                case 1: tamaño_validar(); 
                case 2: aleatorio_mayus(); break;
                case 3: aleatorio_minus(); break;
                case 4: imprimir(); break;
                case 0: break;
                default: JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        } while (opc != 0);
    }
        
       
    public static void main(String[] args) {
      SegundoPunto obj = new SegundoPunto();
      obj.menu();
    }
}

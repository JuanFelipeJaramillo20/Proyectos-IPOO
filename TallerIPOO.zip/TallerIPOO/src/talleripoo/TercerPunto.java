/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talleripoo;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Andom
 */
public class TercerPunto {
    
    private int[] arreglo10;
    private int[] arreglo50;
    private int[] arreglo100;
    private int[] arreglo500;
    private int[] arreglo1000;
 
    public void inicializarArreglosOrdenamiento(){
    
        arreglo10 = new int[10000];
        arreglo50 = new int[50000];
        arreglo100 = new int[100000];
        arreglo500 = new int[500000];
        arreglo1000 = new int[1000000];
        Random generador = new Random();
        
        
        for (int i = 0; i < arreglo10.length; i++) {
            int numeroRandom = generador.nextInt();
            arreglo10[i] = numeroRandom;
            
        }
        for (int i = 0; i < arreglo50.length; i++) {
            int numeroRandom = generador.nextInt();
            arreglo50[i] = numeroRandom;
            
        }
        for (int i = 0; i < arreglo100.length; i++) {
            int numeroRandom = generador.nextInt();
            arreglo100[i] = numeroRandom;
            
        }
        for (int i = 0; i < arreglo500.length; i++) {
            int numeroRandom = generador.nextInt();
            arreglo500[i] = numeroRandom;
            
        }
        for (int i = 0; i < arreglo1000.length; i++) {
            int numeroRandom = generador.nextInt();
            arreglo1000[i] = numeroRandom;
            
        }
    }
    public String insertionSort (int[] arreglo){
        
        String conclusion = "";
        int arregloTemporal[] = new int[arreglo.length];
        arregloTemporal = arreglo.clone();
        
        long tiempoInicial = System.currentTimeMillis();
        long contadorComparaciones = 0;
        long contadorAsignaciones = 0;
        long cantidadIntercambios = 0;
        
        contadorAsignaciones++;
        contadorComparaciones++;
        for (int i = 1; i < arregloTemporal.length; ++i) { 
        
            int llave = arregloTemporal[i]; 
            int j = i - 1; 
            contadorAsignaciones += 2;
            contadorComparaciones++;
            while (j >= 0 && arregloTemporal[j] > llave) { 
                
                arregloTemporal[j + 1] = arregloTemporal[j];
                j = j - 1; 
                cantidadIntercambios++;
                contadorAsignaciones+=3;
                
            } 
            arregloTemporal[j + 1] = llave; 
            contadorAsignaciones+= 2;
        }
        contadorAsignaciones++;
        long tiempoFinal = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFinal - tiempoInicial;
        
        conclusion += "El arreglo ha sido ordenado satisfactoriamente con el método de Inserción. \n"
                + "El algoritmo tardó " + tiempoEjecucion + " milisegundos en ejecutarse.\n"
                        + "Realizó: \n" + contadorComparaciones + " comparaciones.\n"
                                + contadorAsignaciones + " asignaciones. \n"
                                    + cantidadIntercambios + " intercambios. \n";
        
        return conclusion;
        
    }
    
    public String quicksort(int[] arreglo, int izquierda, int derecha) {
        
        String conclusion = "";
        int arregloTemporal[] = new int[arreglo.length];
        arregloTemporal = arreglo.clone();
        long tiempoInicial = System.currentTimeMillis();
        long contadorComparaciones = 0;
        long contadorAsignaciones = 0;
        long cantidadIntercambios = 0;
        int pivote=arregloTemporal[izquierda]; 
        contadorAsignaciones++;
        int i=izquierda;       
        int j=derecha;
        contadorAsignaciones += 2;
        int aux;
        
        while(i < j){ 
            contadorComparaciones++;
           while(arregloTemporal[i] <= pivote && i < j) {
               i++;
               contadorComparaciones++;
           } 
           while(arregloTemporal[j] > pivote) {
               j--;
               contadorComparaciones++;
           }           
           if (i < j) {   
               contadorComparaciones++;
               contadorAsignaciones += 2;
               aux= arreglo[i];                     
               arregloTemporal[i]=arregloTemporal[j];
               arregloTemporal[j]=aux;
               cantidadIntercambios += 1;
           }
   }
        long tiempoFinal = System.currentTimeMillis();
        long tiempoDeEjecucion = tiempoFinal - tiempoInicial;
        
        conclusion += "El arreglo ha sido ordenado satisfactoriamente con el método de Quick Sort. \n"
                + "El algoritmo tardó " + tiempoDeEjecucion + " milisegundos en ejecutarse.\n"
                        + "Realizó: \n" + contadorComparaciones + " comparaciones.\n"
                                + contadorAsignaciones + " asignaciones. \n"
                                        + cantidadIntercambios + " intercambios. \n";
        
        return conclusion;
    }
    
    public String selectionSort(int arreglo[]) { 
        
        String conclusion = "";
        int arregloTemporal[] = new int[arreglo.length];
        arregloTemporal = arreglo.clone();
        long tiempoInicial = System.currentTimeMillis();
        long contadorComparaciones = 0;
        long contadorAsignaciones = 0;
        long cantidadIntercambios = 0;
        int n = arregloTemporal.length; 
        contadorAsignaciones++;
  
  
        for (int i = 0; i < n-1; i++) { 
            contadorComparaciones++; 
            int minimo = i; 
            contadorAsignaciones++;
            for (int j = i+1; j < n; j++) {
                contadorComparaciones++;
               if (arregloTemporal[j] < arregloTemporal[minimo]){
                   contadorComparaciones++;
                   minimo = j;  
                   contadorAsignaciones++;
               } 
            }
            int temporal = arregloTemporal[minimo];
            contadorAsignaciones++;
            arregloTemporal[minimo] = arregloTemporal[i]; 
            cantidadIntercambios++;
            arregloTemporal[i] = temporal; 
            contadorAsignaciones++;
        } 
        long tiempoFinal = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFinal - tiempoInicial;
        
        conclusion += "El arreglo ha sido ordenado satisfactoriamente con el método de Selección. \n"
                + "El algoritmo tardó " + tiempoEjecucion  + " milisegundos en ejecutarse.\n"
                        + "Realizó: \n" + contadorComparaciones + " comparaciones.\n"
                                + contadorAsignaciones + " asignaciones. \n"
                                        + cantidadIntercambios + " intercambios. \n";
        
        return conclusion;
    }
    public void Salida(){
     inicializarArreglosOrdenamiento();
                    char ordenamiento = ' ';
                    do{
                      String subMenuOrdenamiento = JOptionPane.showInputDialog("Bienvenido al submenú de ordenamiento. Aquí haremos pruebas de rendimiento sobre arreglos de distinos tamaños con 3 métodos diferentes de ordenamiento (Inserción, Selección y Quick Sort).\n"
                            + "Por favor que tamaño de arreglo desea probar bajo los 3 métodos anteriormente seleccionados:\n"
                            + "a. Arreglo de 10.000 posiciones.\n"
                            + "b. Arreglo de 50.000 posiciones. \n"
                            + "c. Arreglo de 100.000 posiciones. \n"
                            + "d. Arreglo de 500.000 posiciones. \n"
                            + "e. Arreglo de 1'000.000 posiciones. \n"
                            + "f. Salir del submenú de ordenamiento." );
                    subMenuOrdenamiento = subMenuOrdenamiento.trim();
                    ordenamiento = subMenuOrdenamiento.charAt(0);
                    switch(ordenamiento){
                        case 'a': JOptionPane.showMessageDialog(null, insertionSort(arreglo10) +
                                selectionSort(arreglo10) +
                                quicksort(arreglo10, 0, arreglo10.length - 1));
                        break;
                        case 'b':
                            JOptionPane.showMessageDialog(null, insertionSort(arreglo50) +
                                selectionSort(arreglo50) +
                                quicksort(arreglo50, 0, arreglo50.length - 1));
                            break;
                        case 'c': 
                            JOptionPane.showMessageDialog(null, insertionSort(arreglo100) +
                                selectionSort(arreglo100) +
                                quicksort(arreglo100, 0, arreglo100.length - 1));
                            break;
                        case 'd':
                            JOptionPane.showMessageDialog(null, insertionSort(arreglo500) +
                                selectionSort(arreglo500) +
                                quicksort(arreglo500, 0, arreglo500.length - 1));
                            break;
                        case 'e':
                            JOptionPane.showMessageDialog(null, insertionSort(arreglo1000) +
                                selectionSort(arreglo1000) +
                                quicksort(arreglo1000, 0, arreglo1000.length - 1));
                            break;
                        case 'f':
                            JOptionPane.showMessageDialog(null, "Está saliendo del submenú de ordenamiento. Gracias por utilizar nuestros servicios.");
                            break;
                        default: JOptionPane.showConfirmDialog(null, "Opción Incorrecta. Por favor intente de nuevo.", "Opción Incorrecta", JOptionPane.ERROR_MESSAGE);
                        
                    }  
                }while (ordenamiento != 'f');        
         }
    public static void main(String[] args) {
        TercerPunto obj= new TercerPunto();
        obj.Salida();
    }
}

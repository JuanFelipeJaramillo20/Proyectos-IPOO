/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class Prueba {
    
    public static void main(String[] args) {
        /*
        //------------- leer enteros ------------
        int entero = Utilerias.leerInt("ingrese un numero entero");
        System.out.println(entero);
        
        int enteroEntre = Utilerias.leerInt("ingrese un numero entero entre 5 y 15", 5, 15);
        System.out.println(enteroEntre);
        
        //------------- leer enteros largos ------------
        long largo = Utilerias.leerLong("ingrese un numero entero grande");
        System.out.println(largo);
        
        long largoEntre = Utilerias.leerLong("ingrese un numero entero grande entre 65000 y 65500", 65000, 65500);
        System.out.println(largoEntre);
        
        //------------- leer reales ------------
        double real = Utilerias.leerDouble("ingrese un numero real");
        System.out.println(real);
        
        double realEntre = Utilerias.leerDouble("ingrese un numero real entre -1.5 y 4.5", -1.5, 4.5);
        System.out.println(realEntre);
        
        //------------- leer cadenas ------------
        String cadena = Utilerias.leerCadena("ingrese una cadena");
        System.out.println(cadena);
        */
        String cadenaLongitud = Utilerias.leerCadena("ingrese una cadena [entre 3 y 5 caracteres]", 3, 5);
        System.out.println(cadenaLongitud);
    }
}
